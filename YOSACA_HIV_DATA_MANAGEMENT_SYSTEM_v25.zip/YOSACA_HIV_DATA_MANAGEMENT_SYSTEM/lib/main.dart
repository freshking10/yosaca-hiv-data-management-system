import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';
import 'package:http/http.dart' as http;

const yosacaGreen = Color(0xFF08783E);
const yosacaRed = Color(0xFFC62828);
const secureTokenStorage = FlutterSecureStorage();
const lgAs = <String>[
  'Bade','Bursari','Damaturu','Fika','Fune','Geidam','Gujba','Gulani',
  'Jakusko','Karasuwa','Machina','Nangere','Nguru','Potiskum','Tarmuwa','Yunusari','Yusufari'
];

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LocalStore.instance.database;
  runApp(const YosacaApp());
}

class YosacaApp extends StatelessWidget {
  const YosacaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'YOSACA HIV DATA MANAGEMENT SYSTEM',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: yosacaGreen, primary: yosacaGreen, secondary: yosacaRed), scaffoldBackgroundColor: const Color(0xFFF5F7F6), appBarTheme: const AppBarTheme(backgroundColor: yosacaGreen, foregroundColor: Colors.white), inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(), filled: true, fillColor: Colors.white)),
    home: const LoginScreen(),
  );
}

class AppSession {
  static String role = 'YOSACA Admin';
  static String lga = lgAs.first;
  static String username = '';
  static String? accessToken;
  static String? refreshToken;
  static bool serverAuthenticated = false;
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final user = TextEditingController();
  final pass = TextEditingController();
  String role = 'YOSACA Admin';
  String lga = lgAs.first;
  bool busy = false;
  @override void dispose(){ user.dispose(); pass.dispose(); super.dispose(); }

  Future<void> serverLogin() async {
    if (user.text.trim().isEmpty || pass.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter username and password.'))); return;
    }
    setState(()=>busy=true);
    try {
      final base = SyncService.baseUrl;
      if (base.contains('replace-with-approved-yosaca-api.example')) {
        throw Exception('API address is not configured. Build with --dart-define=YOSACA_API_URL=https://your-approved-server');
      }
      final tokenResponse = await http.post(Uri.parse('$base/api/token/'), headers:{'Content-Type':'application/json'}, body:jsonEncode({'username':user.text.trim(),'password':pass.text})).timeout(const Duration(seconds:20));
      if (tokenResponse.statusCode != 200) throw Exception('Login failed. Check credentials or ask the administrator to activate your account.');
      final tokens = jsonDecode(tokenResponse.body) as Map<String,dynamic>;
      final access = tokens['access'] as String?;
      final refresh = tokens['refresh'] as String?;
      if (access == null || refresh == null) throw Exception('The server returned an incomplete authentication response.');
      final profileResponse = await http.get(Uri.parse('$base/api/me/'),headers:{'Authorization':'Bearer $access'}).timeout(const Duration(seconds:20));
      if (profileResponse.statusCode != 200) throw Exception('Your server account has no valid YOSACA role/LGA assignment. Contact the administrator.');
      final profile = jsonDecode(profileResponse.body) as Map<String,dynamic>;
      final serverRole = profile['role'] as String?;
      final serverLga = profile['lga'] as String?;
      if (serverRole != 'ADMIN' && serverRole != 'LGA') throw Exception('Unsupported server role.');
      if (serverRole == 'LGA' && (serverLga == null || !lgAs.contains(serverLga))) throw Exception('Your account has no valid assigned LGA.');
      final prefs = await SharedPreferences.getInstance();
      // JWTs are stored using platform-backed secure storage, not plain preferences.
      await secureTokenStorage.write(key: 'yosaca_access_token', value: access);
      await secureTokenStorage.write(key: 'yosaca_refresh_token', value: refresh);
      await prefs.setString('yosaca_username', profile['username'] as String? ?? user.text.trim());
      await prefs.setString('yosaca_role', serverRole);
      if (serverLga != null) { await prefs.setString('yosaca_lga', serverLga); } else { await prefs.remove('yosaca_lga'); }
      AppSession.accessToken=access; AppSession.refreshToken=refresh;
      AppSession.username=profile['username'] as String? ?? user.text.trim();
      AppSession.role=serverRole=='ADMIN'?'YOSACA Admin':'LGA Coordinator';
      AppSession.lga=serverLga ?? lgAs.first;
      AppSession.serverAuthenticated=true;
      if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Server sign-in failed: ${e.toString().replaceFirst('Exception: ', '')}')));
    } finally { if (mounted) setState(()=>busy=false); }
  }

  void demoEnter() {
    if (user.text.trim().isEmpty || pass.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a demo username and password.'))); return;
    }
    AppSession.role=role; AppSession.lga=lga; AppSession.username=user.text.trim();
    AppSession.accessToken=null; AppSession.refreshToken=null; AppSession.serverAuthenticated=false;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
  }

  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 460), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    Image.asset('assets/yosaca_logo.png', height: 170, fit: BoxFit.contain), const SizedBox(height: 12),
    const Text('YOSACA HIV DATA MANAGEMENT SYSTEM', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: yosacaGreen)),
    const SizedBox(height: 6), const Text('Offline-first HIV Treatment reporting', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)), const SizedBox(height: 28),
    TextField(controller: user, autocorrect:false, enableSuggestions:false, decoration: const InputDecoration(labelText: 'Username', prefixIcon: Icon(Icons.person_outline))), const SizedBox(height: 12),
    TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline)), onSubmitted: (_) => busy ? null : serverLogin()), const SizedBox(height: 20),
    FilledButton.icon(onPressed:busy?null:serverLogin, icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2,color:Colors.white)):const Icon(Icons.lock_open), label:Padding(padding:const EdgeInsets.all(12),child:Text(busy?'Signing in…':'Sign in securely'))),
    const SizedBox(height: 12), const Text('Secure sign-in requires an approved YOSACA API server and an administrator-created account.', textAlign:TextAlign.center, style:TextStyle(fontSize:12)),
    const Divider(height:32), const Text('DEVELOPMENT / DEMO ONLY',textAlign:TextAlign.center,style:TextStyle(fontWeight:FontWeight.bold,color:yosacaRed)),
    DropdownButtonFormField<String>(value:role,decoration:const InputDecoration(labelText:'Demo role'),items:const [DropdownMenuItem(value:'YOSACA Admin',child:Text('YOSACA Admin')),DropdownMenuItem(value:'LGA Coordinator',child:Text('LGA Coordinator'))],onChanged:(v)=>setState(()=>role=v??role)),
    if(role=='LGA Coordinator') ...[const SizedBox(height:10),DropdownButtonFormField<String>(value:lga,isExpanded:true,decoration:const InputDecoration(labelText:'Demo LGA'),items:lgAs.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>lga=v??lga))],
    const SizedBox(height:10), OutlinedButton(onPressed:busy?null:demoEnter,child:const Text('Continue in local demo mode')),
    const SizedBox(height:8), const Text('Demo mode is not authenticated and must only use synthetic aggregate data. Never enter patient identifiers.',textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:yosacaRed)),
  ])))));
}

class TreatmentRecord {
  final String id, lga, facility, period, reporter, notes, createdAt;
  final int txNew, txCurr, txPvls, txRtt, txMl, vlEligible, vlTested, vlSuppressed;
  final int synced;
  final int demoOnly;
  TreatmentRecord({required this.id,required this.lga,required this.facility,required this.period,required this.reporter,required this.notes,required this.createdAt,required this.txNew,required this.txCurr,required this.txPvls,required this.txRtt,required this.txMl,required this.vlEligible,required this.vlTested,required this.vlSuppressed,this.synced=0,this.demoOnly=0});
  Map<String,Object?> toMap()=>{'id':id,'lga':lga,'facility':facility,'period':period,'reporter':reporter,'notes':notes,'createdAt':createdAt,'txNew':txNew,'txCurr':txCurr,'txPvls':txPvls,'txRtt':txRtt,'txMl':txMl,'vlEligible':vlEligible,'vlTested':vlTested,'vlSuppressed':vlSuppressed,'synced':synced,'demoOnly':demoOnly};
  Map<String,Object?> toApiMap()=>{'id':id,'lga':lga,'facility':facility,'period':period,'reporter':reporter,'notes':notes,'created_at':createdAt,'tx_new':txNew,'tx_curr':txCurr,'tx_pvls':txPvls,'tx_rtt':txRtt,'tx_ml':txMl,'vl_eligible':vlEligible,'vl_tested':vlTested,'vl_suppressed':vlSuppressed};
  bool sameContentAs(TreatmentRecord other) {
    final localDate = DateTime.tryParse(createdAt);
    final remoteDate = DateTime.tryParse(other.createdAt);
    final sameTimestamp = localDate != null && remoteDate != null
        ? localDate.isAtSameMomentAs(remoteDate)
        : createdAt == other.createdAt;
    return id == other.id && lga == other.lga && facility == other.facility &&
      period == other.period && reporter == other.reporter && notes == other.notes &&
      sameTimestamp && txNew == other.txNew && txCurr == other.txCurr &&
      txPvls == other.txPvls && txRtt == other.txRtt && txMl == other.txMl &&
      vlEligible == other.vlEligible && vlTested == other.vlTested &&
      vlSuppressed == other.vlSuppressed;
  }
  factory TreatmentRecord.fromMap(Map<String,Object?> m)=>TreatmentRecord(id:m['id'] as String,lga:m['lga'] as String,facility:m['facility'] as String,period:m['period'] as String,reporter:m['reporter'] as String,notes:(m['notes'] as String?)??'',createdAt:m['createdAt'] as String,txNew:(m['txNew'] as int?)??0,txCurr:(m['txCurr'] as int?)??0,txPvls:(m['txPvls'] as int?)??0,txRtt:(m['txRtt'] as int?)??0,txMl:(m['txMl'] as int?)??0,vlEligible:(m['vlEligible'] as int?)??0,vlTested:(m['vlTested'] as int?)??0,vlSuppressed:(m['vlSuppressed'] as int?)??0,synced:(m['synced'] as int?)??0,demoOnly:(m['demoOnly'] as int?)??0);
  factory TreatmentRecord.fromApiMap(Map<String,dynamic> m)=>TreatmentRecord(id:m['id'].toString(),lga:m['lga'] as String,facility:m['facility'] as String,period:m['period'] as String,reporter:(m['reporter'] as String?)??'',notes:(m['notes'] as String?)??'',createdAt:(m['created_at'] as String?)??DateTime.now().toIso8601String(),txNew:(m['tx_new'] as num?)?.toInt()??0,txCurr:(m['tx_curr'] as num?)?.toInt()??0,txPvls:(m['tx_pvls'] as num?)?.toInt()??0,txRtt:(m['tx_rtt'] as num?)?.toInt()??0,txMl:(m['tx_ml'] as num?)?.toInt()??0,vlEligible:(m['vl_eligible'] as num?)?.toInt()??0,vlTested:(m['vl_tested'] as num?)?.toInt()??0,vlSuppressed:(m['vl_suppressed'] as num?)?.toInt()??0,synced:1,demoOnly:0);
}

class LocalStore {
  LocalStore._(); static final instance=LocalStore._(); Database? _db;
  Future<Database> get database async {
    if(_db!=null)return _db!;
    final base=await getDatabasesPath();
    _db=await openDatabase(p.join(base,'yosaca_hiv_data.db'),version:2,
      onCreate:(db,v) async {
        await db.execute('''CREATE TABLE reports(id TEXT PRIMARY KEY,lga TEXT NOT NULL,facility TEXT NOT NULL,period TEXT NOT NULL,reporter TEXT NOT NULL,notes TEXT NOT NULL,createdAt TEXT NOT NULL,txNew INTEGER NOT NULL,txCurr INTEGER NOT NULL,txPvls INTEGER NOT NULL,txRtt INTEGER NOT NULL,txMl INTEGER NOT NULL,vlEligible INTEGER NOT NULL,vlTested INTEGER NOT NULL,vlSuppressed INTEGER NOT NULL,synced INTEGER NOT NULL DEFAULT 0,demoOnly INTEGER NOT NULL DEFAULT 0)''');
      },
      onUpgrade:(db,oldVersion,newVersion) async {
        if(oldVersion<2) {
          await db.execute('ALTER TABLE reports ADD COLUMN demoOnly INTEGER NOT NULL DEFAULT 0');
          // Fail closed: legacy pending records may have been created in demo mode.
          await db.execute('UPDATE reports SET demoOnly=1 WHERE synced=0');
        }
      });
    return _db!;
  }
  Future<void> save(TreatmentRecord r) async => (await database).insert('reports',r.toMap(),conflictAlgorithm:ConflictAlgorithm.replace);
  Future<List<TreatmentRecord>> all({String? lga}) async { final rows=await (await database).query('reports',where:lga==null?null:'lga = ?',whereArgs:lga==null?null:[lga],orderBy:'period DESC, createdAt DESC'); return rows.map(TreatmentRecord.fromMap).toList(); }
  Future<int> pendingCount() async { final x=await (await database).rawQuery('SELECT COUNT(*) AS c FROM reports WHERE synced=0 AND demoOnly=0'); return Sqflite.firstIntValue(x)??0; }
  Future<int> demoOnlyCount() async { final x=await (await database).rawQuery('SELECT COUNT(*) AS c FROM reports WHERE demoOnly=1'); return Sqflite.firstIntValue(x)??0; }
  Future<int> mergeServerRecords(List<TreatmentRecord> incoming) async {
    final db=await database; var merged=0;
    await db.transaction((txn) async {
      for(final r in incoming) {
        final byId=await txn.query('reports',where:'id=?',whereArgs:[r.id],limit:1);
        if(byId.isNotEmpty) {
          final local = TreatmentRecord.fromMap(byId.first);
          if (!local.sameContentAs(r)) {
            throw StateError('Sync conflict: report ${r.id} exists locally and on the server with different values. Local data was preserved; resolve the conflict before retrying.');
          }
          await txn.update('reports',{'synced':1,'demoOnly':0},where:'id=?',whereArgs:[r.id]);
          continue;
        }
        final localKey=await txn.query('reports',where:'lga=? AND facility=? AND period=?',whereArgs:[r.lga,r.facility,r.period],limit:1);
        if(localKey.isNotEmpty) {
          final local=localKey.first;
          if((local['synced'] as int? ?? 0)==0 && (local['demoOnly'] as int? ?? 0)==0) {
            throw StateError('Sync conflict: a pending local report already exists for ${r.lga}, ${r.facility}, ${r.period}. Local data was preserved; review the duplicate before retrying.');
          }
          await txn.delete('reports',where:'id=?',whereArgs:[local['id']]);
        }
        await txn.insert('reports',r.toMap(),conflictAlgorithm:ConflictAlgorithm.replace); merged++;
      }
    });
    return merged;
  }
  Future<void> markSynced(String id) async => (await database).update('reports',{'synced':1},where:'id=?',whereArgs:[id]);
}

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int tab=0; List<TreatmentRecord> records=[]; int pending=0; bool online=false;
  Map<String, dynamic>? serverSummary;
  String? serverSummaryError;
  DateTime? serverSummaryUpdatedAt;
  String selectedServerPeriod = 'ALL';
  bool get admin=>AppSession.role=='YOSACA Admin';
  @override void initState(){super.initState();refresh();Connectivity().onConnectivityChanged.listen((results){if(mounted)setState(()=>online=!results.contains(ConnectivityResult.none));});}
  Future<void> refresh() async {
    final list=await LocalStore.instance.all(lga:admin?null:AppSession.lga);
    final p=await LocalStore.instance.pendingCount();
    if(mounted) setState(() { records=list..sort((a,b)=>b.createdAt.compareTo(a.createdAt)); pending=p; });
    if (!AppSession.serverAuthenticated || AppSession.accessToken == null) {
      if (mounted) setState(() { serverSummary=null; serverSummaryError=null; serverSummaryUpdatedAt=null; });
      return;
    }
    try {
      final summary=await SyncService.fetchSummary(AppSession.accessToken!, period: selectedServerPeriod == 'ALL' ? null : selectedServerPeriod);
      if(mounted) setState(() { serverSummary=summary; serverSummaryError=null; serverSummaryUpdatedAt=DateTime.now(); });
    } catch(e) {
      if(mounted) setState(() { serverSummaryError=e.toString().replaceFirst('Exception: ', ''); });
    }
  }
  Future<void> addRecord() async { final ok=await Navigator.push<bool>(context,MaterialPageRoute(builder:(_)=>const EntryScreen())); if(ok==true)refresh(); }
  @override Widget build(BuildContext context){ final pages=<Widget>[Dashboard(records:records,pending:pending,online:online,onAdd:addRecord,onRefresh:refresh,admin:admin,serverSummary:serverSummary,serverSummaryError:serverSummaryError,serverSummaryUpdatedAt:serverSummaryUpdatedAt,selectedServerPeriod:selectedServerPeriod,onServerPeriodChanged:(period){setState(()=>selectedServerPeriod=period);refresh();}), ReportsScreen(records:records,onRefresh:refresh), SettingsScreen(onDataChanged:refresh)]; return Scaffold(appBar:AppBar(title:const Text('YOSACA HIV DATA'),actions:[Padding(padding:const EdgeInsets.only(right:12),child:Center(child:Row(children:[Icon(online?Icons.cloud_done:Icons.cloud_off,size:18),const SizedBox(width:5),Text(online?'Online':'Offline')])))]),body:pages[tab],floatingActionButton:tab==0?FloatingActionButton.extended(onPressed:addRecord,icon:const Icon(Icons.add),label:const Text('New report')):null,bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Dashboard'),NavigationDestination(icon:Icon(Icons.assessment_outlined),selectedIcon:Icon(Icons.assessment),label:'Reports'),NavigationDestination(icon:Icon(Icons.settings_outlined),selectedIcon:Icon(Icons.settings),label:'Settings')])); }
}

class Dashboard extends StatelessWidget {
  final List<TreatmentRecord> records; final int pending; final bool online,admin; final VoidCallback onAdd,onRefresh;
  final Map<String, dynamic>? serverSummary; final String? serverSummaryError; final DateTime? serverSummaryUpdatedAt;
  final String selectedServerPeriod; final ValueChanged<String> onServerPeriodChanged;
  const Dashboard({super.key,required this.records,required this.pending,required this.online,required this.admin,required this.onAdd,required this.onRefresh,required this.serverSummary,required this.serverSummaryError,required this.serverSummaryUpdatedAt,required this.selectedServerPeriod,required this.onServerPeriodChanged});
  int sum(int Function(TreatmentRecord) f)=>records.fold(0,(s,r)=>s+f(r));
  int serverTotal(String key) { final totals=serverSummary?['totals']; if(totals is Map<String,dynamic>) { final value=totals[key]; if(value is num) return value.toInt(); } return 0; }
  List<String> get serverPeriods {
    final raw = serverSummary?['by_period'];
    if (raw is! List) return const <String>[];
    final periods = raw.whereType<Map<String, dynamic>>()
        .map((row) => row['period'])
        .whereType<String>()
        .toSet()
        .toList();
    periods.sort((a, b) => b.compareTo(a));
    return periods;
  }
  @override Widget build(BuildContext context){final formatter=NumberFormat('#,##0'); return RefreshIndicator(onRefresh:()async=>onRefresh(),child:ListView(padding:const EdgeInsets.all(16),children:[
    Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:yosacaGreen,borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Welcome, ${AppSession.username}',style:const TextStyle(color:Colors.white70)),const SizedBox(height:5),Text(admin?'Yobe State overview':'${AppSession.lga} LGA overview',style:const TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:6),Text('${records.length} saved report(s) • ${online?'Internet available':'Working offline'}',style:const TextStyle(color:Colors.white))]),),
    const SizedBox(height:16),GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.45,children:[_MetricCard(title:'TX_NEW',value:formatter.format(sum((r)=>r.txNew)),subtitle:'Newly initiated (device)',icon:Icons.person_add_alt_1),_MetricCard(title:'TX_CURR',value:formatter.format(sum((r)=>r.txCurr)),subtitle:'Currently on treatment (device)',icon:Icons.medical_services_outlined),_MetricCard(title:'TX_PVLS',value:formatter.format(sum((r)=>r.txPvls)),subtitle:'Virally suppressed (device)',icon:Icons.health_and_safety_outlined),_MetricCard(title:'Pending sync',value:'$pending',subtitle:'Saved on this device',icon:Icons.sync,color:yosacaRed)]),
    const SizedBox(height:16),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Server aggregate summary • ${admin?'Yobe State':'${AppSession.lga} LGA'}',style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
      const SizedBox(height:4),
      const Text('Server totals are separate from this device’s local totals.',style:TextStyle(fontSize:12,color:Colors.black54)),
      const SizedBox(height:10),
      DropdownButtonFormField<String>(
        value: selectedServerPeriod,
        isExpanded: true,
        decoration: const InputDecoration(labelText: 'Server reporting month', border: OutlineInputBorder()),
        items: [
          const DropdownMenuItem(value: 'ALL', child: Text('All months')),
          ...serverPeriods.map((period) => DropdownMenuItem(value: period, child: Text(period))),
        ],
        onChanged: (period) { if (period != null) onServerPeriodChanged(period); },
      ),
      if(serverSummary != null) ...[
        const SizedBox(height:10),
        Text('${formatter.format(serverTotal('report_count'))} report(s) on server',style:const TextStyle(fontWeight:FontWeight.w600)),
        const SizedBox(height:8),
        Wrap(spacing:14,runSpacing:8,children:[
          Text('TX_NEW  ${formatter.format(serverTotal('tx_new'))}'),Text('TX_CURR  ${formatter.format(serverTotal('tx_curr'))}'),Text('TX_PVLS  ${formatter.format(serverTotal('tx_pvls'))}'),Text('TX_RTT  ${formatter.format(serverTotal('tx_rtt'))}'),Text('TX_ML  ${formatter.format(serverTotal('tx_ml'))}'),Text('VL eligible  ${formatter.format(serverTotal('vl_eligible'))}'),Text('VL tested  ${formatter.format(serverTotal('vl_tested'))}'),Text('VL suppressed  ${formatter.format(serverTotal('vl_suppressed'))}'),
        ]),
        if(serverSummaryUpdatedAt!=null) Padding(padding:const EdgeInsets.only(top:10),child:Text('Last refreshed ${DateFormat('dd MMM yyyy HH:mm').format(serverSummaryUpdatedAt!)}',style:const TextStyle(fontSize:11,color:Colors.black54))),
      ] else if(!AppSession.serverAuthenticated) ...[
        const SizedBox(height:8),const Text('Sign in through the approved server to view official server totals.',style:TextStyle(color:yosacaRed)),
      ] else ...[
        const SizedBox(height:8),Text(serverSummaryError==null?'Loading server summary…':'Server summary unavailable: $serverSummaryError',style:const TextStyle(color:yosacaRed)),
        TextButton.icon(onPressed:onRefresh,icon:const Icon(Icons.refresh),label:const Text('Retry')),
      ],
    ]))),
    const SizedBox(height:20),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Recent reports (this device)',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),TextButton(onPressed:onRefresh,child:const Text('Refresh'))]),
    if(records.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(24),child:Column(children:[Icon(Icons.inbox_outlined,size:40,color:Colors.black38),SizedBox(height:8),Text('No reports saved yet'),Text('Tap “New report” to enter an aggregate facility report.',textAlign:TextAlign.center,style:TextStyle(color:Colors.black54))]))) else ...records.take(6).map((r)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:const Color(0xFFE1F1E8),child:const Icon(Icons.description_outlined,color:yosacaGreen)),title:Text(r.facility, maxLines:1,overflow:TextOverflow.ellipsis),subtitle:Text('${r.lga} • ${r.period}'),trailing:Icon(r.synced==1?Icons.cloud_done_outlined:Icons.cloud_upload_outlined,color:r.synced==1?yosacaGreen:yosacaRed))))
  ])); }
}
class _MetricCard extends StatelessWidget { final String title,value,subtitle; final IconData icon; final Color? color; const _MetricCard({required this.title,required this.value,required this.subtitle,required this.icon,this.color}); @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Icon(icon,color:color??yosacaGreen),Text(value,style:TextStyle(fontSize:23,fontWeight:FontWeight.bold,color:color??yosacaGreen)),Text(title,style:const TextStyle(fontWeight:FontWeight.w700)),Text(subtitle,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11,color:Colors.black54))]))); }

class EntryScreen extends StatefulWidget { const EntryScreen({super.key}); @override State<EntryScreen> createState()=>_EntryScreenState(); }
class _EntryScreenState extends State<EntryScreen> {
  final form=GlobalKey<FormState>(); final facility=TextEditingController(); final reporter=TextEditingController(text:AppSession.username); final notes=TextEditingController(); final fields=<String,TextEditingController>{};
  String lga=AppSession.lga; DateTime period=DateTime(DateTime.now().year,DateTime.now().month); bool saving=false;
  final defs=const [('TX_NEW','Newly initiated on ART'),('TX_CURR','Currently on ART'),('TX_PVLS','Virally suppressed'),('TX_RTT','Returned to treatment'),('TX_ML','Treatment interruption / missed follow-up'),('VL_ELIGIBLE','Eligible for viral-load test'),('VL_TESTED','Viral-load tests completed'),('VL_SUPPRESSED','Viral-load suppressed')];
  @override void initState(){super.initState();for(final d in defs){fields[d.$1]=TextEditingController(text:'0');}}
  @override void dispose(){facility.dispose();reporter.dispose();notes.dispose();for(final c in fields.values){c.dispose();}super.dispose();}
  Future<void> choosePeriod() async {final d=await showDatePicker(context:context,initialDate:period,firstDate:DateTime(2020),lastDate:DateTime(2100),helpText:'Choose any date in reporting month');if(d!=null)setState(()=>period=DateTime(d.year,d.month));}
  Future<void> save() async {if(!form.currentState!.validate())return; setState(()=>saving=true); try {int n(String key)=>int.parse(fields[key]!.text.trim()); if(n('VL_TESTED')>n('VL_ELIGIBLE')) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('VL tested cannot exceed VL eligible.'))); return; } if(n('VL_SUPPRESSED')>n('VL_TESTED')) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('VL suppressed cannot exceed VL tested.'))); return; } final r=TreatmentRecord(id:const Uuid().v4(),lga:lga,facility:facility.text.trim(),period:DateFormat('yyyy-MM').format(period),reporter:reporter.text.trim(),notes:notes.text.trim(),createdAt:DateTime.now().toIso8601String(),txNew:n('TX_NEW'),txCurr:n('TX_CURR'),txPvls:n('TX_PVLS'),txRtt:n('TX_RTT'),txMl:n('TX_ML'),vlEligible:n('VL_ELIGIBLE'),vlTested:n('VL_TESTED'),vlSuppressed:n('VL_SUPPRESSED'),demoOnly:AppSession.serverAuthenticated?0:1);await LocalStore.instance.save(r);if(mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(AppSession.serverAuthenticated?'Report saved on this device and queued for synchronization.':'Demo report saved locally; it will never be uploaded.')));Navigator.pop(context,true);}}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not save: $e')));}finally{if(mounted)setState(()=>saving=false);}}
  String? validateInt(String? v){if(v==null||v.trim().isEmpty)return 'Required';final n=int.tryParse(v.trim());if(n==null||n<0)return 'Enter a whole number ≥ 0';return null;}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('New HIV Treatment Report')),body:Form(key:form,child:ListView(padding:const EdgeInsets.all(16),children:[const Text('Report details',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:12),DropdownButtonFormField<String>(value:lga,decoration:const InputDecoration(labelText:'LGA'),items:lgAs.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:AppSession.role=='YOSACA Admin'?(v)=>setState(()=>lga=v??lga):null),const SizedBox(height:12),TextFormField(controller:facility,decoration:const InputDecoration(labelText:'Health facility name'),validator:(v)=>v==null||v.trim().isEmpty?'Required':null),const SizedBox(height:12),InkWell(onTap:choosePeriod,child:InputDecorator(decoration:const InputDecoration(labelText:'Reporting month',suffixIcon:Icon(Icons.calendar_month)),child:Text(DateFormat('MMMM yyyy').format(period)))),const SizedBox(height:12),TextFormField(controller:reporter,decoration:const InputDecoration(labelText:'Reporting officer'),validator:(v)=>v==null||v.trim().isEmpty?'Required':null),const SizedBox(height:22),const Text('HIV Treatment Indicators',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:4),const Text('Enter aggregate counts only. Do not enter names or patient identifiers.',style:TextStyle(color:yosacaRed)),const SizedBox(height:12),...defs.map((d)=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextFormField(controller:fields[d.$1],keyboardType:TextInputType.number,validator:validateInt,decoration:InputDecoration(labelText:d.$1,helperText:d.$2,prefixIcon:const Icon(Icons.numbers))))),TextFormField(controller:notes,maxLines:3,decoration:const InputDecoration(labelText:'Notes (optional)',alignLabelWithHint:true)),const SizedBox(height:20),FilledButton.icon(onPressed:saving?null:save,icon:const Icon(Icons.save_outlined),label:Padding(padding:const EdgeInsets.all(12),child:Text(saving?'Saving…':'Save report offline'))),const SizedBox(height:8),const Text('Indicators and calculation rules must be validated against the approved YOSACA/state reporting definitions before operational use.',style:TextStyle(fontSize:12,color:Colors.black54))])));
}

class ReportsScreen extends StatefulWidget {
  final List<TreatmentRecord> records;
  final VoidCallback onRefresh;
  const ReportsScreen({super.key, required this.records, required this.onRefresh});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  String selectedPeriod = 'ALL';

  List<String> get periods => widget.records.map((r) => r.period).toSet().toList()..sort((a, b) => b.compareTo(a));
  List<TreatmentRecord> get visibleRecords => selectedPeriod == 'ALL'
      ? widget.records
      : widget.records.where((r) => r.period == selectedPeriod).toList();
  int total(int Function(TreatmentRecord) field) => visibleRecords.fold(0, (sum, r) => sum + field(r));

  Future<void> exportPdf(BuildContext context) async {
    final data = visibleRecords;
    final doc = pw.Document();
    final rows = data.map((r) => [
      r.lga, r.facility, r.period, '${r.txNew}', '${r.txCurr}', '${r.txPvls}',
      '${r.txRtt}', '${r.txMl}', '${r.vlTested}/${r.vlEligible}',
    ]).toList();
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4.landscape,
      build: (ctx) => [
        pw.Text('YOSACA HIV DATA MANAGEMENT SYSTEM', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 4),
        pw.Text('HIV Treatment Aggregate Report • Period: ${selectedPeriod == 'ALL' ? 'All months' : selectedPeriod}'),
        pw.Text('Generated ${DateFormat('dd MMM yyyy HH:mm').format(DateTime.now())} • ${data.length} report(s)'),
        pw.SizedBox(height: 10),
        pw.Text('Totals — TX_NEW: ${total((r) => r.txNew)} | TX_CURR: ${total((r) => r.txCurr)} | TX_PVLS: ${total((r) => r.txPvls)} | TX_RTT: ${total((r) => r.txRtt)} | TX_ML: ${total((r) => r.txMl)}'),
        pw.Text('Viral load — Eligible: ${total((r) => r.vlEligible)} | Tested: ${total((r) => r.vlTested)} | Suppressed: ${total((r) => r.vlSuppressed)}'),
        pw.SizedBox(height: 14),
        pw.TableHelper.fromTextArray(
          headers: ['LGA', 'Facility', 'Month', 'TX_NEW', 'TX_CURR', 'TX_PVLS', 'TX_RTT', 'TX_ML', 'VL tested/eligible'],
          data: rows.isEmpty ? [['—', 'No reports saved for this filter', '—', '—', '—', '—', '—', '—', '—']] : rows,
          headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
          headerDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFF08783E)),
          cellStyle: const pw.TextStyle(fontSize: 8),
          cellAlignment: pw.Alignment.centerLeft,
        ),
        pw.SizedBox(height: 12),
        pw.Text('Confidential aggregate health data. Protect this report and share only with authorized personnel.', style: const pw.TextStyle(fontSize: 9)),
      ],
    ));
    await Printing.layoutPdf(onLayout: (format) => doc.save(), name: 'yosaca_hiv_treatment_${selectedPeriod == 'ALL' ? 'all_months' : selectedPeriod}.pdf');
  }

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Reports & exports', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('${visibleRecords.length} report(s) match this filter.'),
      const SizedBox(height: 12),
      InputDecorator(
        decoration: const InputDecoration(labelText: 'Reporting month', border: OutlineInputBorder()),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            isExpanded: true,
            value: selectedPeriod,
            items: [
              const DropdownMenuItem(value: 'ALL', child: Text('All months')),
              ...periods.map((period) => DropdownMenuItem(value: period, child: Text(period))),
            ],
            onChanged: (value) => setState(() => selectedPeriod = value ?? 'ALL'),
          ),
        ),
      ),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Aggregate totals', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('TX_NEW  ${NumberFormat('#,##0').format(total((r) => r.txNew))}'),
        Text('TX_CURR  ${NumberFormat('#,##0').format(total((r) => r.txCurr))}'),
        Text('TX_PVLS  ${NumberFormat('#,##0').format(total((r) => r.txPvls))}'),
        Text('TX_RTT  ${NumberFormat('#,##0').format(total((r) => r.txRtt))}'),
        Text('TX_ML  ${NumberFormat('#,##0').format(total((r) => r.txMl))}'),
        const Divider(),
        Text('VL eligible ${NumberFormat('#,##0').format(total((r) => r.vlEligible))} • tested ${NumberFormat('#,##0').format(total((r) => r.vlTested))} • suppressed ${NumberFormat('#,##0').format(total((r) => r.vlSuppressed))}'),
      ]))),
      Card(child: ListTile(leading: const Icon(Icons.picture_as_pdf, color: yosacaRed, size: 34), title: const Text('Export filtered PDF report'), subtitle: const Text('Includes aggregate totals and the report rows matching the selected month.'), trailing: const Icon(Icons.chevron_right), onTap: () => exportPdf(context))),
      Card(child: ListTile(leading: const Icon(Icons.refresh, color: yosacaGreen), title: const Text('Refresh reports'), subtitle: const Text('Reload locally saved reports.'), onTap: widget.onRefresh)),
      const SizedBox(height: 8),
      ...visibleRecords.map((r) => Card(child: ListTile(
        title: Text('${r.lga} • ${r.period}'),
        subtitle: Text('${r.facility}\nTX_NEW ${r.txNew}  |  TX_CURR ${r.txCurr}  |  TX_PVLS ${r.txPvls}'),
        isThreeLine: true,
        trailing: Icon(r.synced == 1 ? Icons.cloud_done : Icons.cloud_off, color: r.synced == 1 ? yosacaGreen : yosacaRed),
      ))),
    ],
  );
}

class SettingsScreen extends StatefulWidget { final VoidCallback onDataChanged; const SettingsScreen({super.key,required this.onDataChanged});
  @override State<SettingsScreen> createState()=>_SettingsScreenState();
}
class _SettingsScreenState extends State<SettingsScreen> {
  bool syncing=false;
  Future<void> syncNow() async {
    if (!AppSession.serverAuthenticated || AppSession.accessToken==null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Sync is disabled in demo mode. Sign in through the approved server first.'))); return;
    }
    setState(()=>syncing=true);
    try { final uploaded = await SyncService.pushPending(AppSession.accessToken!, lga: AppSession.role=='LGA Coordinator'?AppSession.lga:null); final downloaded = await SyncService.pullServerReports(AppSession.accessToken!, lga: AppSession.role=='LGA Coordinator'?AppSession.lga:null); if(mounted) { widget.onDataChanged(); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Sync complete: $uploaded uploaded, $downloaded downloaded.'))); } }
    catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Sync failed: ${e.toString().replaceFirst('Exception: ', '')}'))); }
    finally { if(mounted) setState(()=>syncing=false); }
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Settings',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:12),Card(child:ListTile(leading:Icon(AppSession.serverAuthenticated?Icons.verified_user:Icons.warning_amber,color:AppSession.serverAuthenticated?yosacaGreen:yosacaRed),title:Text(AppSession.role),subtitle:Text('Signed in as ${AppSession.username} • ${AppSession.serverAuthenticated?'Server authenticated':'DEMO — not authenticated'}'))),Card(child:ListTile(leading:const Icon(Icons.sync_outlined,color:yosacaGreen),title:Text(syncing?'Synchronizing reports…':'Synchronize reports'),subtitle:Text('Uploads pending reports and downloads authorized server reports. API: ${SyncService.baseUrl}'),trailing:const Icon(Icons.cloud_upload_outlined),onTap:syncing?null:syncNow)),const Card(child:ListTile(leading:Icon(Icons.phone_android),title:Text('Offline storage'),subtitle:Text('Reports are saved in a local SQLite database. Only server-authenticated sessions can upload.'))),const Card(child:ListTile(leading:Icon(Icons.security_outlined,color:yosacaRed),title:Text('Production security required'),subtitle:Text('Use HTTPS, approved accounts, secure token storage, audit logs, access controls, backups, and a privacy review before real health data is used.'))),const Card(child:ListTile(leading:Icon(Icons.info_outline),title:Text('Build status'),subtitle:Text('Source project only; not a production-ready or signed APK.'))),const SizedBox(height:12),FilledButton.tonalIcon(onPressed:()async{final p=await SharedPreferences.getInstance();await secureTokenStorage.delete(key:'yosaca_access_token');await secureTokenStorage.delete(key:'yosaca_refresh_token');await p.remove('yosaca_username');await p.remove('yosaca_role');await p.remove('yosaca_lga');AppSession.accessToken=null;AppSession.refreshToken=null;AppSession.serverAuthenticated=false;if(context.mounted)Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder:(_)=>const LoginScreen()),(_)=>false);},icon:const Icon(Icons.logout),label:const Text('Sign out'))]);
}

/// Uploads local pending aggregate reports to the authenticated API.
/// Refreshes an expired access token once, then retries the failed request once.
class SyncService {
  static const String baseUrl = String.fromEnvironment('YOSACA_API_URL', defaultValue: 'https://replace-with-approved-yosaca-api.example');

  static Future<String> _refreshAccessToken() async {
    final refresh = AppSession.refreshToken;
    if (refresh == null || refresh.isEmpty) throw Exception('Session expired. Sign in again.');
    final response = await http.post(
      Uri.parse('$baseUrl/api/token/refresh/'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'refresh': refresh}),
    ).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) throw Exception('Session expired. Sign in again.');
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    final access = body['access'] as String?;
    if (access == null || access.isEmpty) throw Exception('The server did not return a refreshed access token.');
    AppSession.accessToken = access;
    await secureTokenStorage.write(key: 'yosaca_access_token', value: access);
    return access;
  }

  static Future<http.Response> _upload(TreatmentRecord report, String token) async => http.post(
    Uri.parse('$baseUrl/api/reports/'),
    headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
    body: jsonEncode(report.toApiMap()),
  ).timeout(const Duration(seconds: 30));

  static Future<Map<String, dynamic>> fetchSummary(String bearerToken, {String? period}) async {
    if (baseUrl.contains('replace-with-approved-yosaca-api.example')) throw Exception('API address is not configured.');
    final connectivity = await Connectivity().checkConnectivity();
    if (connectivity.contains(ConnectivityResult.none)) throw Exception('No internet connection');
    var token = bearerToken;
    Uri summaryUri() => Uri.parse('$baseUrl/api/summary/').replace(queryParameters: period == null ? null : {'period': period});
    Future<http.Response> fetch(String t) => http.get(summaryUri(), headers: {'Authorization': 'Bearer $t'}).timeout(const Duration(seconds: 20));
    var response = await fetch(token);
    if (response.statusCode == 401) { token = await _refreshAccessToken(); response = await fetch(token); }
    if (response.statusCode == 401) throw Exception('Authentication expired. Sign in again.');
    if (response.statusCode == 403) throw Exception('Server denied permission to view the aggregate summary.');
    if (response.statusCode < 200 || response.statusCode >= 300) throw Exception('Summary request failed (${response.statusCode}).');
    final decoded = jsonDecode(response.body);
    if (decoded is! Map<String, dynamic> || decoded['totals'] is! Map<String, dynamic>) throw Exception('Unexpected aggregate summary response from server.');
    return decoded;
  }

  static Future<int> pullServerReports(String bearerToken, {String? lga}) async {
    if (baseUrl.contains('replace-with-approved-yosaca-api.example')) throw Exception('API address is not configured.');
    final connectivity = await Connectivity().checkConnectivity();
    if (connectivity.contains(ConnectivityResult.none)) throw Exception('No internet connection');
    var token = bearerToken;
    Future<http.Response> fetch(String t) => http.get(Uri.parse('$baseUrl/api/reports/'),headers:{'Authorization':'Bearer $t'}).timeout(const Duration(seconds:30));
    var response = await fetch(token);
    if(response.statusCode==401) { token=await _refreshAccessToken(); response=await fetch(token); }
    if(response.statusCode==401) throw Exception('Authentication expired. Sign in again.');
    if(response.statusCode==403) throw Exception('Server denied permission to download reports.');
    if(response.statusCode<200 || response.statusCode>=300) throw Exception('Download failed (${response.statusCode}).');
    final decoded=jsonDecode(response.body);
    final List<dynamic> rows=decoded is List ? decoded : (decoded is Map<String,dynamic> && decoded['results'] is List ? decoded['results'] as List<dynamic> : throw Exception('Unexpected reports response from server.'));
    final records=rows.whereType<Map<String,dynamic>>().map(TreatmentRecord.fromApiMap).toList();
    return LocalStore.instance.mergeServerRecords(records);
  }

  static Future<int> pushPending(String bearerToken, {String? lga}) async {
    if (baseUrl.contains('replace-with-approved-yosaca-api.example')) {
      throw Exception('API address is not configured. Use --dart-define=YOSACA_API_URL=https://your-approved-server');
    }
    final connectivity = await Connectivity().checkConnectivity();
    if (connectivity.contains(ConnectivityResult.none)) throw Exception('No internet connection');
    final pending = (await LocalStore.instance.all(lga: lga)).where((r) => r.synced == 0 && r.demoOnly == 0).toList();
    var token = bearerToken;
    var uploaded = 0;
    for (final report in pending) {
      var response = await _upload(report, token);
      if (response.statusCode == 401) {
        token = await _refreshAccessToken();
        response = await _upload(report, token);
      }
      if (response.statusCode >= 200 && response.statusCode < 300) {
        await LocalStore.instance.markSynced(report.id);
        uploaded++;
      } else if (response.statusCode == 401) {
        throw Exception('Authentication expired. Sign in again; $uploaded report(s) uploaded before this error.');
      } else if (response.statusCode == 403) {
        throw Exception('Server denied permission for this report. Check the account LGA assignment; $uploaded report(s) uploaded before this error.');
      } else if (response.statusCode == 409) {
        throw Exception('Conflict for report ${report.id}: a report may already exist for this facility/month, or the same report ID has different values. $uploaded report(s) uploaded before this error; remaining reports are still on this device.');
      } else if (response.statusCode == 400) {
        throw Exception('Server rejected report ${report.id} (400). Check reporting period and indicator values; $uploaded report(s) uploaded before this error.');
      } else {
        throw Exception('Upload failed (${response.statusCode}); $uploaded report(s) uploaded before this error. Pending reports remain on this device.');
      }
    }
    return uploaded;
  }
}

import 'package:flutter_test/flutter_test.dart';
import 'package:yosaca_hiv_data_management_system/main.dart';

TreatmentRecord sample({String createdAt = '2026-09-15T10:00:00.000Z'}) => TreatmentRecord(
  id: '00000000-0000-4000-8000-000000000001',
  lga: 'Damaturu',
  facility: 'Synthetic Test Facility',
  period: '2026-09',
  reporter: 'Test Reporter',
  notes: '',
  createdAt: createdAt,
  txNew: 1,
  txCurr: 20,
  txPvls: 18,
  txRtt: 2,
  txMl: 0,
  vlEligible: 10,
  vlTested: 9,
  vlSuppressed: 8,
);

void main() {
  test('API payload uses backend snake_case keys and omits local-only flags', () {
    final payload = sample().toApiMap();
    expect(payload['created_at'], '2026-09-15T10:00:00.000Z');
    expect(payload['tx_new'], 1);
    expect(payload['vl_suppressed'], 8);
    expect(payload.containsKey('createdAt'), isFalse);
    expect(payload.containsKey('synced'), isFalse);
    expect(payload.containsKey('demoOnly'), isFalse);
  });

  test('server payload can be mapped back into a synced local record', () {
    final record = TreatmentRecord.fromApiMap(Map<String, dynamic>.from(sample().toApiMap()));
    expect(record.id, sample().id);
    expect(record.lga, 'Damaturu');
    expect(record.synced, 1);
    expect(record.demoOnly, 0);
  });

  test('same-content comparison tolerates equivalent timezone timestamps', () {
    final a = sample(createdAt: '2026-09-15T10:00:00Z');
    final b = sample(createdAt: '2026-09-15T11:00:00+01:00');
    expect(a.sameContentAs(b), isTrue);
  });
}

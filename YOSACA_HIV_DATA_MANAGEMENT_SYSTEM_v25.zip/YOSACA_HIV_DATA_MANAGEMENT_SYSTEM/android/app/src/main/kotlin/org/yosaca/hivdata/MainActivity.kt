package org.yosaca.hivdata

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

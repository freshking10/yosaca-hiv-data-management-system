# YOSACA HIV DATA MANAGEMENT SYSTEM — yadda ake hada Android app

Wannan jagora yana taimaka wa mai kwamfuta ya gina APK daga source code. ZIP din nan ba ya dauke da APK da aka riga aka gina.

## Abubuwan da ake bukata

- Flutter stable SDK da Dart (Flutter ya zo da Dart).
- Android Studio tare da Android SDK da Android platform/build tools.
- Python 3.
- Intanet don sauke Flutter packages da Gradle dependencies.

## Hanya mafi sauki (Linux/macOS)

1. Cire ZIP din zuwa folder.
2. Bude Terminal a babban folder `YOSACA_HIV_DATA_MANAGEMENT_SYSTEM`.
3. Gudanar da:

   ```bash
   chmod +x scripts/build_android_apk.sh
   ./scripts/build_android_apk.sh
   ```

4. Idan an riga an tura backend zuwa sahihin HTTPS host da aka amince da shi, saita URL kafin gini:

   ```bash
   YOSACA_API_URL=https://your-approved-api-host ./scripts/build_android_apk.sh
   ```

   Kada a saka kalmomin sirri ko API secrets cikin `--dart-define`. Idan ba a da server da aka amince da shi, gina APK don gwajin UI/offline kawai.

## Windows

Ana iya amfani da PowerShell tare da Flutter da Python a PATH. Mafi tabbatacciyar hanya ita ce kunna WSL/Git Bash sannan a gudanar da `scripts/build_android_apk.sh`. Fayil din `.bat` yana nan a matsayin taimako, amma yana bukatar `bash` da za su iya gudanar da `prepare_android_build.sh`.

## Inda APK zai kasance

Idan duk preflight, `flutter pub get`, `flutter analyze`, `flutter test`, da build sun yi nasara:

`build/app/outputs/flutter-apk/app-debug.apk`

Sanya wayar Android a USB debugging ko kwafe APK din zuwa waya, sannan a girka shi don gwaji. Ba a hada production signing key da wannan aikin ba.

## Idan ana son APK daga GitHub

1. Kirkiri private GitHub repository bisa dokokin kungiyar.
2. Tura source code din nan.
3. Bude **Actions → Flutter Android checks**.
4. Jira duk matakan su yi nasara.
5. Sauke artifact `yosaca-android-debug-apk` daga workflow run mai nasara.

## Muhimman iyakoki

- Wannan starter ba a tabbatar da shi a matsayin production system ba. README ya bayyana cewa wasu sassan shiga/sync ba su kammala haɗuwa end-to-end ba.
- Debug APK ba production release ba ne.
- Sai an kammala Django/Flutter tests, device acceptance tests, API HTTPS deployment, backup/restore, security/privacy review da amincewar mai bayanan YOSACA kafin amfani na ainihi.
- Yi amfani da synthetic aggregate data kawai. Kada a shigar da sunaye, lambobin waya, patient IDs ko bayanan mutum ɗaya.


## Hanya mafi sauki idan ba ka da Flutter a kwamfutarka: GitHub Actions

Wannan hanya tana buƙatar GitHub account da damar ƙirƙirar repository. Ba za a iya samar da APK daga ZIP a wannan hira kai tsaye ba, domin ba a girka Flutter/Android SDK a muhallin ginin ba kuma ba a da damar intanet don sauke su.

1. Cire ZIP ɗin v25 a kwamfuta.
2. Ƙirƙiri **private repository** a GitHub bisa dokokin ƙungiyar.
3. Loda dukkan fayilolin da ke cikin babban folder `YOSACA_HIV_DATA_MANAGEMENT_SYSTEM` zuwa repository (ba ZIP ɗin da aka matse ba).
4. Buɗe shafin **Actions** a repository.
5. Zaɓi workflow **Flutter Android checks** sannan danna **Run workflow**.
6. Jira aikin ya gama. Idan ya gaza, buɗe matakin da ya yi ja ka duba kuskuren; kada a ɗauka an gina APK.
7. Idan duk matakai sun yi nasara, buɗe workflow run ɗin sannan ka sauke artifact mai suna `yosaca-android-debug-apk`.
8. Cire artifact ɗin ZIP; a ciki ne `app-debug.apk` zai kasance. Wannan APK na gwaji ne kawai.

**Muhimmi:** Kada a sanya sirrin API ko kalmomin sirri a cikin source code ko `--dart-define`. Yi amfani da synthetic aggregate data kawai har sai an kammala haɗin backend, gwajin na'ura, bitar tsaro/ƙa'idojin sirri da amincewar mai bayanan YOSACA.

# Android build guide

This repository contains the Flutter source and Android app configuration. It does **not** include a prebuilt APK or a signing key.

## Build locally

1. Install the Flutter stable SDK and Android Studio / Android SDK.
2. From the project root, run:

   ```bash
   ./scripts/prepare_android_build.sh
   flutter pub get
   flutter analyze
   flutter test
   flutter build apk --debug --dart-define=YOSACA_API_URL=https://your-approved-api-host
   ```

3. The debug APK is created at `build/app/outputs/flutter-apk/app-debug.apk`.
4. Configure a real HTTPS API host only after the backend is deployed and approved. Do not put credentials or production secrets in `--dart-define`.

## Build with GitHub Actions

Push the project to a GitHub repository and run the **Flutter Android checks** workflow. It analyzes Dart, runs tests, builds a debug APK, and uploads `yosaca-android-debug-apk` as a workflow artifact. Download that artifact from the successful workflow run.

The debug APK is for controlled testing only. A production release requires a managed Android signing key, HTTPS deployment, operational monitoring, backups, access review, and security/privacy approval. Use synthetic aggregate data until approval is complete.

## App identity

- Android application ID: `org.yosaca.hivdata`
- Display name: `YOSACA HIV DATA`
- Flutter version: `0.2.0+2`
- The YOSACA launcher icon is configured for standard Android density buckets and as an adaptive icon on Android 8.0+.

The build workflow produces a **debug** APK for controlled testing. It is not a production-signed release. A release APK/AAB must be built and signed using an approved, securely managed organization key after review.

# YOSACA v23 release handoff

## Changes in this handoff

- Extended `.gitignore` to keep local Python caches, virtual environments, SQLite databases, `.env` files, private key/certificate files, and Android APK/AAB build outputs out of normal source-control commits.
- Kept `backend/.env.example` trackable as a template; it must contain placeholders only, never production secrets.
- Retained the dependency-light preflight and release-readiness checklist from v22.

## Verify before packaging

From the project root:

```sh
python scripts/preflight_release.py
python -m compileall -q backend
```

Then in an environment with dependencies installed:

```sh
cd backend
DJANGO_TEST_SQLITE=1 DJANGO_SECRET_KEY=ci-only-not-for-production python manage.py check
DJANGO_TEST_SQLITE=1 DJANGO_SECRET_KEY=ci-only-not-for-production python manage.py makemigrations --check --dry-run
DJANGO_TEST_SQLITE=1 DJANGO_SECRET_KEY=ci-only-not-for-production python manage.py test reports
cd ..
flutter pub get
flutter analyze
flutter test
flutter build apk --debug --dart-define=YOSACA_API_URL=https://your-approved-api-host
```

## Validation boundary

This handoff has not been validated by running Django tests, Flutter analysis/tests, or compiling/installing an APK in this environment. A source preflight is not evidence that the application is production-ready. Do not include real credentials, private keys, or patient-level data in the repository. Use synthetic aggregate data until formal security/privacy and data-owner approvals are complete.

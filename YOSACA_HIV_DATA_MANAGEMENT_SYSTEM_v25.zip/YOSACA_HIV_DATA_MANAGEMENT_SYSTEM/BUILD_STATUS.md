# Build status — v11

## Included
- Flutter offline aggregate-report entry, SQLite persistence, PDF export, and demo mode separated from server-authenticated uploads.
- JWT sign-in with server-assigned role/LGA and secure storage for mobile tokens.
- Django API with role-scoped report access, report validation, idempotent retries, and immutable report endpoints pending an approved correction workflow.
- Minimal audit events for successful API report creation, written in the same database transaction as the report and exposed read-only in Django admin.
- Regression tests for permissions, duplicate handling, validation, and audit event creation/rejection.
- Docker deployment starter, environment template, health endpoint, and CI workflow.

## Verification in this build environment
- Python source compilation passed (`python -m compileall`).
- ZIP integrity checked after packaging.
- Django tests and migration checks have **not** been run here because Django is not installed in this environment.
- Flutter analysis, Flutter tests, Android build, live HTTPS API testing, and deployment checks have not been run.

## Still required before operational use
- Run backend CI/tests and migration checks in a Python environment with requirements installed.
- Run `flutter pub get`, `flutter analyze`, and `flutter test`, then build and test a signed Android APK.
- Deploy the API behind approved HTTPS infrastructure, configure secret management, backups/restore, centralized audit logging, monitoring, account provisioning, and access reviews.
- Complete security/privacy review and obtain approval from the responsible YOSACA/state data owner.
- Use synthetic aggregate data only until the service is approved. Never enter patient identifiers into this aggregate-reporting starter.


## v12 additions
- Added authenticated `GET /api/summary/` endpoint with role-scoped aggregate totals and month-grouped counts; does not return facility names, reporter names, or notes.
- Added tests for coordinator LGA scoping, admin totals, invalid period filters, and fail-closed access for unprofiled users.
- Backend test execution and Flutter/Android builds remain pending in an environment with dependencies and SDKs installed.

## v13 additions
- Reports screen now supports filtering saved reports by reporting month or viewing all months.
- The filtered view displays aggregate totals for TX_NEW, TX_CURR, TX_PVLS, TX_RTT, TX_ML, and viral-load indicators.
- PDF export now respects the selected month filter and includes the aggregate totals plus the matching report rows.
- The PDF filename identifies the selected month (or all months) to reduce accidental confusion between exports.
- These Flutter changes have not been compiled or device-tested in this environment because Flutter/Dart SDKs are unavailable.

## v14 dashboard integration
- Connected the Flutter dashboard to the authenticated `/api/summary/` endpoint.
- The dashboard presents server-side aggregate totals separately from totals calculated from records stored on the current device.
- The summary endpoint remains responsible for access scoping: YOSACA Admin sees state-wide totals, while an LGA Coordinator receives only the assigned LGA totals.
- The UI shows the last successful refresh time and a retry action if the server summary cannot be loaded.
- Validation in this environment: Python backend syntax compilation and `pubspec.yaml` YAML parsing passed; Flutter/Dart analysis and runtime tests could not be run because the SDK is unavailable.

## v15 incremental update
- Added a reporting-month selector for the server aggregate summary on the Flutter dashboard, using the backend's `period=YYYY-MM` filter.
- Kept the list of available months unfiltered by the selected month, while filtering only the headline totals; this allows users to switch between months without losing the other month options.
- Added a backend regression test for the summary period selector using synthetic data.
- Validation available in this environment: Python syntax compilation and archive integrity checks. Flutter/Dart and Django runtime tests remain unrun because those SDK/packages are not installed here.

## v16 Android assembly work
- Added the Android `MainActivity.kt` entry point, which was missing from the source package.
- Added `scripts/prepare_android_build.sh` to generate missing Gradle wrapper files using an installed Flutter SDK without overwriting the project's existing Gradle configuration.
- Added a GitHub Actions workflow to run `flutter pub get`, `flutter analyze`, `flutter test`, and build a debug APK; successful builds are uploaded as an artifact.
- Added unit tests for API payload field names, local-only flag exclusion, API-to-local mapping, and timestamp equivalence during sync conflict checks.
- Added `ANDROID_BUILD_GUIDE.md` with local and CI build instructions.
- Local APK compilation remains unverified because this environment has Java but no Flutter/Dart SDK or Android SDK. No APK is claimed as built in this package.

## v17 Android app identity and packaging polish
- Replaced the generic Android launcher icon with YOSACA-branded launcher assets for mdpi through xxxhdpi and an Android adaptive icon for API 26+.
- Updated the Android manifest to use the YOSACA launcher icon.
- Incremented the Flutter package version to `0.2.0+2` for the next build artifact.
- Updated the Android build guide to document the app identity and artifact expectations.
- Validation available here: launcher image assets generated and checked, XML/YAML parsing and ZIP integrity checks can be performed. Flutter compilation and device installation remain unverified because Flutter/Dart and Android SDKs are not installed in this environment.

## v18 verification and handoff
- Re-checked Python backend syntax compilation successfully in the available environment.
- Re-checked YAML parsing for `pubspec.yaml` and both GitHub Actions workflow files successfully.
- Confirmed that this environment does not have Django, Flutter, or Dart installed; therefore backend runtime tests, Dart analysis/tests, and APK compilation have not been executed locally.
- Kept the Android CI workflow as the supported route to generate a controlled-testing debug APK. The APK is only produced after a successful GitHub Actions run; this source archive does not contain a built APK.
- Removed Python `__pycache__` and `.pyc` artifacts from the handoff package to keep it source-focused.
- Operational restriction remains: use synthetic aggregate data only until the API host, security/privacy review, and responsible YOSACA data-owner approvals are in place.


## v19 Android version synchronization
- Fixed the Android Gradle app configuration to use `flutter.versionCode` and `flutter.versionName` instead of hard-coded `1` / `0.1.0`. This keeps the generated APK aligned with the Flutter package version `0.2.0+2` in `pubspec.yaml`.
- Static validation performed: Android XML parsed, YAML parsed, backend Python sources compiled, and the source archive integrity checked.
- Flutter analysis/tests, Django runtime tests, and APK compilation remain unverified because the required SDKs/dependencies are not installed in this environment.


## v20 handoff — production configuration guardrails

- Added fail-fast production startup checks for unset/default `DJANGO_ALLOWED_HOSTS` and missing/example PostgreSQL passwords. The explicit `DJANGO_TEST_SQLITE=1` CI/test path is exempt from production database configuration checks.
- Trimmed host entries when parsing `DJANGO_ALLOWED_HOSTS`.
- Restricted GitHub Actions token permissions to repository contents read-only and added concurrency cancellation for superseded workflow runs.
- Updated backend deployment documentation.
- Validation performed in this environment: Python source compilation, YAML parsing, XML parsing where applicable, and archive integrity. Django runtime tests and Flutter/Android builds still require the SDK/dependencies and CI execution; they are not claimed as passed here.

## v21 CI workflow trigger correction
- Corrected both GitHub Actions workflow files so `push` and `pull_request` are top-level workflow events rather than mistakenly nested under `concurrency`. The Android workflow also keeps `workflow_dispatch` at the event level, so it can be started manually from GitHub Actions.
- This fixes a workflow configuration issue that could prevent automated checks and APK builds from triggering as intended.
- Validation performed: parsed both workflow files with YAML's base loader and asserted the expected event, permission, concurrency, and job keys; compiled backend Python sources; checked archive integrity.
- CI itself has not been run from this environment. Flutter/Django execution and APK output still require GitHub Actions or a machine with the necessary SDKs and dependencies.

## v22 release preflight and deployment gate
- Added `scripts/preflight_release.py`, a dependency-light source preflight that checks required handoff files, Android manifest XML, backend Python syntax, Flutter package identity/version, and expected Android CI artifact steps when available.
- Added `RELEASE_READINESS_CHECKLIST.md` covering CI checks, Android device acceptance tests, production secrets/HTTPS/PostgreSQL, backup restoration, access review, data governance, and the production release gate.
- The preflight is intentionally explicit that it does not replace Django tests, Flutter analysis/tests, APK compilation, API integration, or security/privacy review.

## v23 source hygiene and release handoff
- Extended `.gitignore` to exclude local Python caches, virtual environments, SQLite databases, `.env` files (while keeping `.env.example`), private key/certificate files, and Android APK/AAB build outputs.
- Added `RELEASE_HANDOFF_v23.md` with repeatable preflight and dependency-backed verification commands.
- These are source hygiene and handoff improvements only. Django runtime tests, Flutter analysis/tests, APK build/device tests, and production security review remain pending in a properly provisioned environment.


## v24 app assembly handoff
- Added `scripts/build_android_apk.sh`, a single-entrypoint controlled-testing build that runs source preflight, prepares Android wrapper files, resolves Flutter dependencies, analyzes Dart, runs Flutter tests, builds a debug APK, and checks that a non-empty APK exists.
- Added Hausa assembly instructions in `ASSEMBLE_APP_HAUSA.md`.
- Bumped Flutter package version to `0.2.1+3` so the next APK has a new version code/name.
- Updated preflight required files to cover the new build entrypoint and Hausa guide.
- This environment still has no Flutter/Dart SDK or Android SDK, so it cannot compile or validate the APK. The script is a reproducible build path, not proof of a successful build. Production login/sync integration and formal security/privacy approval remain release blockers.


## v25 APK assembly handoff
- Android CI now runs the dependency-light source preflight before preparing the Gradle wrapper and checks that the generated debug APK is non-empty before uploading the artifact.
- Expanded the Hausa assembly guide with step-by-step GitHub Actions artifact retrieval instructions for users without a local Flutter/Android SDK.
- Validation available here: source preflight, Python syntax, YAML/XML parsing, and ZIP integrity. No APK is claimed: Flutter/Dart/Android SDK are unavailable and network DNS is unavailable in this environment.

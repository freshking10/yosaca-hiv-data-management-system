# YOSACA HIV Data Management System — assembled starter package

Android-first, English-language Flutter application for YOSACA state staff covering all 17 LGAs in Yobe State. The app is designed for aggregate HIV Treatment indicator reporting and offline entry.

## Included
- Flutter Android source under `lib/`, with the supplied YOSACA logo asset.
- Local SQLite report storage, indicator entry, dashboard, report list and PDF export.
- Role-selection prototype for YOSACA Admin and LGA Coordinator.
- Django REST Framework + PostgreSQL API starter under `backend/`, with JWT token endpoints and server-side LGA filtering.
- Build and deployment notes below and in `backend/README.md`.

## Build Android APK
Build requires Flutter SDK, Android SDK/Android Studio, and network access to fetch packages. Flutter/Android build tools are not bundled in this ZIP.

```bash
cd YOSACA_HIV_DATA_MANAGEMENT_SYSTEM
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

Expected output after a successful build: `build/app/outputs/flutter-apk/app-release.apk`.

## Important status
This ZIP is the assembled source project, **not an APK** and not a deployed production service. The login screen is still a prototype: it currently lets the user choose a role locally and does not authenticate against the API. The API starter and local offline database are not yet connected end-to-end. The backend now exposes `GET /api/me/` to return a server-assigned role/LGA after JWT authentication, but the Flutter login does not call it yet. Do not use real patient identifiers or operational patient data until YOSACA/state owners approve the design and independent security/privacy testing is complete.

## Before operational use
1. Configure and deploy the backend on an approved HTTPS host and PostgreSQL service.
2. Replace prototype login with JWT authentication and bind the user's role/LGA to server-issued identity; never trust a role selected on the device.
3. Finish and test upload/download synchronization, retry behavior, duplicate handling, update conflicts, and server acknowledgements.
4. Validate indicator definitions and reporting rules (TX_NEW, TX_CURR, TX_PVLS, TX_RTT, TX_ML, viral-load coverage) with the data owner.
5. Add audit logs, secure token storage, encrypted local storage where required, account lifecycle controls, backups, restore drills, and privacy/retention policies.
6. Test access boundaries: coordinators must see only their assigned LGA; authorized YOSACA Admin users can see all 17 LGAs.
7. Build, sign, and distribute the APK through an approved channel after tests pass.

## Data handling
The app is intended for aggregate counts only. Do not enter patient names, phone numbers, identifiers, or other patient-level data. Reports may still be confidential operational health data and should be shared only with authorized personnel.

## Latest source update

See `BUILD_STATUS.md` for the current implementation boundary. The backend now includes an initial database migration, a database-aware `/health/` readiness endpoint, a Docker Compose deployment starter, SQLite-backed CI test configuration, and additional viral-load count consistency checks. These additions do not mean the API is deployed or the mobile login/sync is production-connected.


## API identity endpoint
After obtaining a JWT from `POST /api/token/`, an authenticated client can call `GET /api/me/`. The endpoint returns the username, server-configured role (`ADMIN` or `LGA`), and the assigned LGA for coordinators. Accounts without a valid YOSACA profile are rejected. The current Flutter prototype does not yet consume this endpoint; do not rely on its local role selector for access control.


## Mobile server sign-in (prototype integration)
The Flutter app can request a JWT from `/api/token/`, then reads the server-assigned role and LGA from `/api/me/`. Configure the approved HTTPS API host at build time with `--dart-define=YOSACA_API_URL=https://your-approved-api-host`. The default host is intentionally a placeholder. The separate demo path is unauthenticated and must only be used with synthetic data. Server-side user profiles and approved accounts must be provisioned by an administrator. See `BUILD_STATUS.md` for known limitations.


## v6 sync behavior

- Pending aggregate reports upload one at a time and are marked synced only after a successful 2xx response.
- If an upload receives HTTP 401, the app attempts one access-token refresh and retries that upload once.
- A rejected upload stops the batch and reports how many earlier reports succeeded; remaining reports stay pending locally.
- Configure the approved HTTPS API using `--dart-define=YOSACA_API_URL=https://your-approved-server`. Never use real data against an unapproved or unsecured server.
- JWT access and refresh tokens use `flutter_secure_storage`; non-secret display preferences use SharedPreferences. Verify Android secure-storage behavior on target devices and complete a security review before production.


### v7 synchronization and demo-data safety
- With an approved server URL configured via `--dart-define=YOSACA_API_URL=https://your-approved-server`, a server-authenticated user can upload eligible pending aggregate reports and download reports permitted by the server account.
- Local demo-mode records are tagged as demo-only and excluded from upload. On upgrading an existing local database, unsynchronized legacy records are conservatively tagged demo-only to avoid accidentally uploading demo data.
- Synchronization has not been tested against a live deployment in this package. Review duplicate facility/month policy, secure token storage, audit logging, backup/restore, and privacy controls before operational use.


### v9 token storage improvement
- JWT access and refresh tokens are stored with `flutter_secure_storage` rather than plain SharedPreferences. Signing out removes the secure token entries.
- This is a security improvement, not a complete security certification; device testing, key lifecycle review, and an approved deployment remain required.


### v10 data-integrity safeguards

- Server-side report updates and deletes are disabled until an audited correction process is approved.
- During server downloads, a same-ID or same-facility/month conflict with pending local data now raises a visible sync error rather than silently marking a different local report as synced or replacing pending data.
- Backend regression tests cover the immutable API behavior and malformed reporting months.

### Reports screen (v13)
The Reports tab can filter saved aggregate reports by reporting month or show all months. Its totals card summarizes the currently visible reports, and PDF export includes the same filter and totals. These are device-local totals based on records currently stored on the phone; they are not a substitute for a verified server-wide summary unless the relevant reports have been synchronized and authorized.

### Dashboard server summary (v14)
When signed in to an approved API server, the dashboard requests `/api/summary/` and displays server aggregate totals separately from local device totals. The backend scopes the response according to the server-assigned account role and LGA. In demo mode, the app does not present demo counts as official server totals.


## One-command Android assembly (v24)
For the guided controlled-testing build, see `ASSEMBLE_APP_HAUSA.md` or run `./scripts/build_android_apk.sh` on a machine with Flutter stable, Python 3, and Android SDK installed. The script runs preflight, analysis, tests, and debug APK build. A successful APK is written to `build/app/outputs/flutter-apk/app-debug.apk`. This ZIP itself is source code and does not include a prebuilt APK.

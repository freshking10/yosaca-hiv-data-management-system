from datetime import datetime, timezone
from uuid import uuid4

from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase

from .models import TreatmentReport, UserProfile


class TreatmentReportPermissionTests(APITestCase):
    def setUp(self):
        User = get_user_model()
        self.coordinator = User.objects.create_user(username='coordinator', password='Test-only-pass-123!')
        UserProfile.objects.create(user=self.coordinator, role='LGA', lga='Damaturu')
        self.admin = User.objects.create_user(username='yosaca-admin', password='Test-only-pass-123!')
        UserProfile.objects.create(user=self.admin, role='ADMIN')
        self.damaturu_report = TreatmentReport.objects.create(
            id=uuid4(), lga='Damaturu', facility='Demo Facility A', period='2026-09',
            reporter='Demo Reporter', notes='', created_at=datetime(2026, 9, 1, tzinfo=timezone.utc),
            tx_new=1, tx_curr=20, tx_pvls=18, tx_rtt=0, tx_ml=0,
            vl_eligible=20, vl_tested=19, vl_suppressed=18, updated_by=self.admin,
        )
        TreatmentReport.objects.create(
            id=uuid4(), lga='Potiskum', facility='Demo Facility B', period='2026-09',
            reporter='Demo Reporter', notes='', created_at=datetime(2026, 9, 1, tzinfo=timezone.utc),
            tx_new=2, tx_curr=30, tx_pvls=25, tx_rtt=0, tx_ml=0,
            vl_eligible=30, vl_tested=28, vl_suppressed=25, updated_by=self.admin,
        )

    def test_coordinator_only_sees_assigned_lga(self):
        self.client.force_authenticate(self.coordinator)
        response = self.client.get('/api/reports/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual([item['lga'] for item in response.data], ['Damaturu'])

    def test_coordinator_cannot_submit_for_another_lga(self):
        self.client.force_authenticate(self.coordinator)
        response = self.client.post('/api/reports/', {
            'id': str(uuid4()), 'lga': 'Potiskum', 'facility': 'Demo Facility C',
            'period': '2026-09', 'reporter': 'Demo Reporter', 'notes': '',
            'created_at': '2026-09-01T00:00:00Z', 'tx_new': 0, 'tx_curr': 0,
            'tx_pvls': 0, 'tx_rtt': 0, 'tx_ml': 0, 'vl_eligible': 0,
            'vl_tested': 0, 'vl_suppressed': 0,
        }, format='json')
        self.assertEqual(response.status_code, 400)
        self.assertFalse(TreatmentReport.objects.filter(facility='Demo Facility C').exists())

    def test_admin_can_see_all_lgas(self):
        self.client.force_authenticate(self.admin)
        response = self.client.get('/api/reports/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual({item['lga'] for item in response.data}, {'Damaturu', 'Potiskum'})

    def test_unprofiled_user_sees_no_reports_and_cannot_create(self):
        user = get_user_model().objects.create_user(username='unconfigured', password='Test-only-pass-123!')
        self.client.force_authenticate(user)
        response = self.client.get('/api/reports/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 0)
        create_response = self.client.post('/api/reports/', {
            'id': str(uuid4()), 'lga': 'Damaturu', 'facility': 'Demo Facility D',
            'period': '2026-09', 'reporter': 'Demo Reporter', 'notes': '',
            'created_at': '2026-09-01T00:00:00Z', 'tx_new': 0, 'tx_curr': 0,
            'tx_pvls': 0, 'tx_rtt': 0, 'tx_ml': 0, 'vl_eligible': 0,
            'vl_tested': 0, 'vl_suppressed': 0,
        }, format='json')
        self.assertEqual(create_response.status_code, 403)

    def test_profile_endpoint_returns_server_assigned_lga(self):
        self.client.force_authenticate(self.coordinator)
        response = self.client.get('/api/me/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, {
            'username': 'coordinator', 'role': 'LGA', 'lga': 'Damaturu'
        })

    def test_profile_endpoint_rejects_unprofiled_user(self):
        user = get_user_model().objects.create_user(username='no-profile', password='Test-only-pass-123!')
        self.client.force_authenticate(user)
        response = self.client.get('/api/me/')
        self.assertEqual(response.status_code, 403)


    def test_identical_retry_is_idempotent(self):
        self.client.force_authenticate(self.admin)
        report_id = uuid4()
        payload = {
            'id': str(report_id), 'lga': 'Damaturu', 'facility': 'Retry Demo Facility',
            'period': '2026-10', 'reporter': 'Synthetic Tester', 'notes': 'retry test',
            'created_at': '2026-10-01T00:00:00Z', 'tx_new': 1, 'tx_curr': 10,
            'tx_pvls': 9, 'tx_rtt': 0, 'tx_ml': 0, 'vl_eligible': 10,
            'vl_tested': 10, 'vl_suppressed': 9,
        }
        first = self.client.post('/api/reports/', payload, format='json')
        second = self.client.post('/api/reports/', payload, format='json')
        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 200)
        self.assertEqual(TreatmentReport.objects.filter(pk=report_id).count(), 1)
        from .models import ReportAuditEvent
        self.assertEqual(ReportAuditEvent.objects.filter(report_id=report_id).count(), 1)

    def test_reusing_report_id_with_different_values_returns_conflict(self):
        self.client.force_authenticate(self.admin)
        report_id = uuid4()
        payload = {
            'id': str(report_id), 'lga': 'Damaturu', 'facility': 'Retry Conflict Facility',
            'period': '2026-10', 'reporter': 'Synthetic Tester', 'notes': '',
            'created_at': '2026-10-01T00:00:00Z', 'tx_new': 1, 'tx_curr': 10,
            'tx_pvls': 9, 'tx_rtt': 0, 'tx_ml': 0, 'vl_eligible': 10,
            'vl_tested': 10, 'vl_suppressed': 9,
        }
        first = self.client.post('/api/reports/', payload, format='json')
        payload['tx_curr'] = 11
        second = self.client.post('/api/reports/', payload, format='json')
        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 409)
        self.assertEqual(TreatmentReport.objects.filter(pk=report_id).count(), 1)

    def test_different_report_id_for_same_facility_month_returns_conflict(self):
        self.client.force_authenticate(self.admin)
        payload = {
            'id': str(uuid4()), 'lga': 'Damaturu', 'facility': 'Demo Facility A',
            'period': '2026-09', 'reporter': 'Synthetic Tester', 'notes': '',
            'created_at': '2026-09-01T00:00:00Z', 'tx_new': 1, 'tx_curr': 20,
            'tx_pvls': 18, 'tx_rtt': 0, 'tx_ml': 0, 'vl_eligible': 20,
            'vl_tested': 19, 'vl_suppressed': 18,
        }
        response = self.client.post('/api/reports/', payload, format='json')
        self.assertEqual(response.status_code, 409)

    def test_viral_load_counts_must_be_consistent(self):
        self.client.force_authenticate(self.admin)
        response = self.client.post('/api/reports/', {
            'id': str(uuid4()), 'lga': 'Damaturu', 'facility': 'Invalid synthetic facility',
            'period': '2026-10', 'reporter': 'Synthetic Tester', 'notes': '',
            'created_at': '2026-10-01T00:00:00Z', 'tx_new': 0, 'tx_curr': 0,
            'tx_pvls': 0, 'tx_rtt': 0, 'tx_ml': 0, 'vl_eligible': 10,
            'vl_tested': 11, 'vl_suppressed': 9,
        }, format='json')
        self.assertEqual(response.status_code, 400)
        self.assertFalse(TreatmentReport.objects.filter(facility='Invalid synthetic facility').exists())

    def test_report_updates_and_deletes_are_disabled_until_audited_workflow_exists(self):
        self.client.force_authenticate(self.admin)
        report_id = str(self.damaturu_report.id)
        patch_response = self.client.patch(
            f'/api/reports/{report_id}/', {'notes': 'change'}, format='json'
        )
        delete_response = self.client.delete(f'/api/reports/{report_id}/')
        self.assertEqual(patch_response.status_code, 405)
        self.assertEqual(delete_response.status_code, 405)
        self.damaturu_report.refresh_from_db()
        self.assertEqual(self.damaturu_report.notes, '')

    def test_invalid_reporting_period_is_rejected(self):
        self.client.force_authenticate(self.admin)
        response = self.client.post('/api/reports/', {
            'id': str(uuid4()), 'lga': 'Damaturu', 'facility': 'Period Test Facility',
            'period': '2026-13', 'reporter': 'Synthetic Tester', 'notes': '',
            'created_at': '2026-10-01T00:00:00Z', 'tx_new': 0, 'tx_curr': 0,
            'tx_pvls': 0, 'tx_rtt': 0, 'tx_ml': 0, 'vl_eligible': 0,
            'vl_tested': 0, 'vl_suppressed': 0,
        }, format='json')
        self.assertEqual(response.status_code, 400)
        self.assertFalse(TreatmentReport.objects.filter(facility='Period Test Facility').exists())


    def test_successful_report_creation_writes_audit_event(self):
        from .models import ReportAuditEvent
        self.client.force_authenticate(self.coordinator)
        response = self.client.post('/api/reports/', {
            'id': str(uuid4()), 'lga': 'Damaturu', 'facility': 'Audit Test Facility',
            'period': '2026-10', 'reporter': 'Synthetic Tester', 'notes': '',
            'created_at': '2026-10-01T00:00:00Z', 'tx_new': 1, 'tx_curr': 5,
            'tx_pvls': 4, 'tx_rtt': 0, 'tx_ml': 0, 'vl_eligible': 5,
            'vl_tested': 5, 'vl_suppressed': 4,
        }, format='json')
        self.assertEqual(response.status_code, 201)
        event = ReportAuditEvent.objects.get(report__facility='Audit Test Facility')
        self.assertEqual(event.actor, self.coordinator)
        self.assertEqual(event.action, 'REPORT_CREATED')
        self.assertEqual(event.metadata, {'source': 'api'})

    def test_rejected_cross_lga_report_does_not_write_audit_event(self):
        from .models import ReportAuditEvent
        before = ReportAuditEvent.objects.count()
        self.client.force_authenticate(self.coordinator)
        response = self.client.post('/api/reports/', {
            'id': str(uuid4()), 'lga': 'Potiskum', 'facility': 'Rejected Audit Facility',
            'period': '2026-10', 'reporter': 'Synthetic Tester', 'notes': '',
            'created_at': '2026-10-01T00:00:00Z', 'tx_new': 0, 'tx_curr': 0,
            'tx_pvls': 0, 'tx_rtt': 0, 'tx_ml': 0, 'vl_eligible': 0,
            'vl_tested': 0, 'vl_suppressed': 0,
        }, format='json')
        self.assertIn(response.status_code, (400, 403))
        self.assertEqual(ReportAuditEvent.objects.count(), before)


class ReportSummaryPermissionTests(APITestCase):
    def setUp(self):
        User = get_user_model()
        self.coordinator = User.objects.create_user(username='summary-coordinator', password='Test-only-pass-123!')
        UserProfile.objects.create(user=self.coordinator, role='LGA', lga='Damaturu')
        self.admin = User.objects.create_user(username='summary-admin', password='Test-only-pass-123!')
        UserProfile.objects.create(user=self.admin, role='ADMIN')
        TreatmentReport.objects.create(
            id=uuid4(), lga='Damaturu', facility='Synthetic Summary Facility A', period='2026-09',
            reporter='Synthetic Reporter', notes='', created_at=datetime(2026, 9, 1, tzinfo=timezone.utc),
            tx_new=2, tx_curr=20, tx_pvls=18, tx_rtt=1, tx_ml=0,
            vl_eligible=20, vl_tested=19, vl_suppressed=18, updated_by=self.admin,
        )
        TreatmentReport.objects.create(
            id=uuid4(), lga='Potiskum', facility='Synthetic Summary Facility B', period='2026-09',
            reporter='Synthetic Reporter', notes='', created_at=datetime(2026, 9, 1, tzinfo=timezone.utc),
            tx_new=3, tx_curr=30, tx_pvls=25, tx_rtt=0, tx_ml=1,
            vl_eligible=30, vl_tested=28, vl_suppressed=25, updated_by=self.admin,
        )

    def test_coordinator_summary_is_lga_scoped_and_aggregate_only(self):
        self.client.force_authenticate(self.coordinator)
        response = self.client.get('/api/summary/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['scope'], 'Damaturu')
        self.assertEqual(response.data['totals']['report_count'], 1)
        self.assertEqual(response.data['totals']['tx_curr'], 20)
        self.assertNotIn('facility', response.data)
        self.assertNotIn('reporter', response.data)
        self.assertNotIn('notes', response.data)
        self.assertEqual(len(response.data['by_period']), 1)
        self.assertEqual(response.data['by_period'][0]['period'], '2026-09')

    def test_admin_summary_covers_all_lgas(self):
        self.client.force_authenticate(self.admin)
        response = self.client.get('/api/summary/?period=2026-09')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['scope'], 'all_lgas')
        self.assertEqual(response.data['totals']['report_count'], 2)
        self.assertEqual(response.data['totals']['tx_curr'], 50)

    def test_summary_rejects_invalid_period(self):
        self.client.force_authenticate(self.admin)
        response = self.client.get('/api/summary/?period=2026-13')
        self.assertEqual(response.status_code, 400)

    def test_unprofiled_user_cannot_access_summary(self):
        user = get_user_model().objects.create_user(username='summary-no-profile', password='Test-only-pass-123!')
        self.client.force_authenticate(user)
        response = self.client.get('/api/summary/')
        self.assertEqual(response.status_code, 403)


    def test_period_filter_changes_totals_but_keeps_available_periods(self):
        TreatmentReport.objects.create(
            id=uuid4(), lga='Damaturu', facility='Synthetic August Facility', period='2026-08',
            reporter='Synthetic Reporter', notes='', created_at=datetime(2026, 8, 1, tzinfo=timezone.utc),
            tx_new=1, tx_curr=10, tx_pvls=9, tx_rtt=0, tx_ml=0,
            vl_eligible=10, vl_tested=10, vl_suppressed=9, updated_by=self.admin,
        )
        self.client.force_authenticate(self.admin)
        response = self.client.get('/api/summary/?period=2026-09')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['totals']['report_count'], 2)
        self.assertEqual([row['period'] for row in response.data['by_period']], ['2026-09', '2026-08'])

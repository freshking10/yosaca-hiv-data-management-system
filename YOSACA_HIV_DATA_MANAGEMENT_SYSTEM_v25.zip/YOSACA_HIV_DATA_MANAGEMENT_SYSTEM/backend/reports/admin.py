from django.contrib import admin
from .models import UserProfile, TreatmentReport, ReportAuditEvent
admin.site.register(UserProfile)
@admin.register(TreatmentReport)
class TreatmentReportAdmin(admin.ModelAdmin):
    list_display = ('lga','facility','period','tx_new','tx_curr','updated_by','updated_at')
    list_filter = ('lga','period')
    search_fields = ('facility','reporter')


@admin.register(ReportAuditEvent)
class ReportAuditEventAdmin(admin.ModelAdmin):
    list_display = ('occurred_at', 'action', 'report', 'actor')
    list_filter = ('action', 'occurred_at')
    search_fields = ('report__facility', 'report__lga', 'actor__username')
    readonly_fields = ('actor', 'report', 'action', 'occurred_at', 'metadata')

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

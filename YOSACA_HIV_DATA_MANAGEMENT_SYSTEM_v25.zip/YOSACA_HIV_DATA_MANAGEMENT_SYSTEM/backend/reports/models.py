from django.conf import settings
from django.db import models

LGAS = [(x, x) for x in ['Bade','Bursari','Damaturu','Fika','Fune','Geidam','Gujba','Gulani','Jakusko','Karasuwa','Machina','Nangere','Nguru','Potiskum','Tarmuwa','Yunusari','Yusufari']]

class UserProfile(models.Model):
    ROLE_CHOICES = [('ADMIN','YOSACA Admin'), ('LGA','LGA Coordinator')]
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='yosaca_profile')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    lga = models.CharField(max_length=40, choices=LGAS, blank=True)
    def __str__(self): return f'{self.user.username} ({self.role})'

class TreatmentReport(models.Model):
    id = models.UUIDField(primary_key=True, editable=False)
    lga = models.CharField(max_length=40, choices=LGAS, db_index=True)
    facility = models.CharField(max_length=180)
    period = models.CharField(max_length=7, db_index=True) # YYYY-MM
    reporter = models.CharField(max_length=120)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField()
    tx_new = models.PositiveIntegerField(default=0)
    tx_curr = models.PositiveIntegerField(default=0)
    tx_pvls = models.PositiveIntegerField(default=0)
    tx_rtt = models.PositiveIntegerField(default=0)
    tx_ml = models.PositiveIntegerField(default=0)
    vl_eligible = models.PositiveIntegerField(default=0)
    vl_tested = models.PositiveIntegerField(default=0)
    vl_suppressed = models.PositiveIntegerField(default=0)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['lga','facility','period'], name='unique_facility_lga_month')]
        ordering = ['-period','lga','facility']
    def __str__(self): return f'{self.lga} / {self.facility} / {self.period}'


class ReportAuditEvent(models.Model):
    """Append-only record of sensitive report actions; do not store report values here."""
    ACTION_CHOICES = [('REPORT_CREATED', 'Report created')]
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='yosaca_audit_events')
    report = models.ForeignKey(TreatmentReport, on_delete=models.PROTECT, related_name='audit_events')
    action = models.CharField(max_length=40, choices=ACTION_CHOICES)
    occurred_at = models.DateTimeField(auto_now_add=True, db_index=True)
    # Deliberately minimal metadata: no clinical counts, notes, or patient identifiers.
    metadata = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ['-occurred_at']

    def __str__(self):
        return f'{self.action} report={self.report_id} actor={self.actor_id}'

from rest_framework import viewsets, permissions
from rest_framework.exceptions import PermissionDenied
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework import status
from django.db import IntegrityError, transaction
from django.db.models import Count, Sum
import re
from .models import TreatmentReport, ReportAuditEvent
from .serializers import TreatmentReportSerializer

class TreatmentReportViewSet(viewsets.ModelViewSet):
    # Reports are immutable through the mobile API until an audited correction
    # workflow is approved. This prevents accidental PATCH/PUT/DELETE loss.
    http_method_names = ['get', 'post', 'head', 'options']
    serializer_class = TreatmentReportSerializer
    permission_classes = [permissions.IsAuthenticated]
    def get_queryset(self):
        qs = TreatmentReport.objects.select_related('updated_by').all()
        profile = getattr(self.request.user, 'yosaca_profile', None)
        if profile is None:
            # Fail closed: account must have an explicitly configured YOSACA role.
            return qs.none()
        if profile.role == 'LGA':
            return qs.filter(lga=profile.lga)
        if profile.role == 'ADMIN':
            return qs
        return qs.none()
    def create(self, request, *args, **kwargs):
        """Make retrying a timed-out mobile upload safe for the same report UUID.

        If the server stored a report but the response was lost, the device can
        retry the POST. An identical retry returns the existing report instead
        of being stuck on a duplicate-primary-key error. Reusing an ID with
        different values is rejected as a conflict.
        """
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        profile = getattr(request.user, 'yosaca_profile', None)
        if profile is None:
            raise PermissionDenied('YOSACA role is not configured for this account.')
        if profile.role == 'LGA' and serializer.validated_data['lga'] != profile.lga:
            raise PermissionDenied('You may only submit reports for your assigned LGA.')

        report_id = serializer.validated_data.get('id')
        existing = self.get_queryset().filter(pk=report_id).first() if report_id else None
        if existing is not None:
            compared_fields = (
                'lga', 'facility', 'period', 'reporter', 'notes', 'created_at',
                'tx_new', 'tx_curr', 'tx_pvls', 'tx_rtt', 'tx_ml',
                'vl_eligible', 'vl_tested', 'vl_suppressed',
            )
            identical = all(
                getattr(existing, field) == serializer.validated_data.get(field, getattr(existing, field))
                for field in compared_fields
            )
            if identical:
                return Response(self.get_serializer(existing).data, status=status.HTTP_200_OK)
            return Response(
                {'detail': 'This report ID already exists with different values.'},
                status=status.HTTP_409_CONFLICT,
            )

        try:
            with transaction.atomic():
                self.perform_create(serializer)
                ReportAuditEvent.objects.create(
                    actor=request.user,
                    report=serializer.instance,
                    action='REPORT_CREATED',
                    metadata={'source': 'api'},
                )
        except IntegrityError:
            # Covers concurrent retries and the unique LGA/facility/month rule.
            return Response(
                {'detail': 'A report already exists for this facility and reporting month, or the report ID is already in use.'},
                status=status.HTTP_409_CONFLICT,
            )
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def perform_create(self, serializer):
        profile = getattr(self.request.user, 'yosaca_profile', None)
        if profile is None: raise PermissionDenied('YOSACA role is not configured for this account.')
        if profile.role == 'LGA' and serializer.validated_data['lga'] != profile.lga:
            raise PermissionDenied('You may only submit reports for your assigned LGA.')
        serializer.save(updated_by=self.request.user)


@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def current_user_profile(request):
    """Return the server-assigned role and LGA; never trust device role selection."""
    profile = getattr(request.user, 'yosaca_profile', None)
    if profile is None:
        return Response({'detail': 'YOSACA role is not configured for this account.'}, status=403)
    if profile.role == 'LGA' and not profile.lga:
        return Response({'detail': 'An assigned LGA is required for this account.'}, status=403)
    if profile.role not in ('ADMIN', 'LGA'):
        return Response({'detail': 'Unsupported YOSACA role.'}, status=403)
    return Response({
        'username': request.user.get_username(),
        'role': profile.role,
        'lga': profile.lga if profile.role == 'LGA' else None,
    })


@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def report_summary(request):
    """Return aggregate-only summaries, scoped to the authenticated user's role."""
    profile = getattr(request.user, 'yosaca_profile', None)
    if profile is None or profile.role not in ('ADMIN', 'LGA'):
        return Response({'detail': 'YOSACA role is not configured for this account.'}, status=403)
    if profile.role == 'LGA' and not profile.lga:
        return Response({'detail': 'An assigned LGA is required for this account.'}, status=403)

    period = request.query_params.get('period')
    if period and not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])', period):
        return Response({'period': 'Use YYYY-MM format.'}, status=400)

    # Keep the month selector populated from all periods visible to this user,
    # while applying the optional period filter only to the requested totals.
    scoped_reports = TreatmentReport.objects.all()
    if profile.role == 'LGA':
        scoped_reports = scoped_reports.filter(lga=profile.lga)
    reports = scoped_reports.filter(period=period) if period else scoped_reports

    fields = ('tx_new', 'tx_curr', 'tx_pvls', 'tx_rtt', 'tx_ml',
              'vl_eligible', 'vl_tested', 'vl_suppressed')
    aggregate = {'report_count': Count('id')}
    aggregate.update({field: Sum(field) for field in fields})
    totals = reports.aggregate(**aggregate)
    totals = {key: (value or 0) for key, value in totals.items()}

    by_period = scoped_reports.values('period').annotate(
        report_count=Count('id'),
        **{field: Sum(field) for field in fields},
    ).order_by('-period')
    periods = []
    for row in by_period:
        periods.append({key: (value or 0) for key, value in row.items()})

    response = {'scope': 'all_lgas' if profile.role == 'ADMIN' else profile.lga,
                'period_filter': period, 'totals': totals, 'by_period': periods}
    return Response(response)

from rest_framework import serializers
from .models import TreatmentReport, LGAS

class TreatmentReportSerializer(serializers.ModelSerializer):
    # Explicitly writable: the offline-first mobile app assigns a stable UUID
    # before upload so retries can be made idempotent.
    id = serializers.UUIDField(required=True)
    class Meta:
        model = TreatmentReport
        fields = ['id','lga','facility','period','reporter','notes','created_at','tx_new','tx_curr','tx_pvls','tx_rtt','tx_ml','vl_eligible','vl_tested','vl_suppressed','updated_at']
        read_only_fields = ['updated_at']
    def validate_period(self, value):
        import re
        if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])', value):
            raise serializers.ValidationError('Use YYYY-MM format.')
        return value
    def validate(self, attrs):
        # Viral-load cascade counts must be internally consistent.
        eligible = attrs.get('vl_eligible', getattr(self.instance, 'vl_eligible', 0))
        tested = attrs.get('vl_tested', getattr(self.instance, 'vl_tested', 0))
        suppressed = attrs.get('vl_suppressed', getattr(self.instance, 'vl_suppressed', 0))
        errors = {}
        if tested > eligible:
            errors['vl_tested'] = 'VL tested cannot exceed VL eligible.'
        if suppressed > tested:
            errors['vl_suppressed'] = 'VL suppressed cannot exceed VL tested.'
        if errors:
            raise serializers.ValidationError(errors)
        return attrs

    def validate_lga(self, value):
        request = self.context['request']
        profile = getattr(request.user, 'yosaca_profile', None)
        if profile and profile.role == 'LGA' and profile.lga != value:
            raise serializers.ValidationError('You may only submit reports for your assigned LGA.')
        return value

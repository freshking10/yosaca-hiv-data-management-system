from rest_framework.routers import DefaultRouter
from .views import TreatmentReportViewSet
router = DefaultRouter()
router.register('reports', TreatmentReportViewSet, basename='report')
urlpatterns = router.urls

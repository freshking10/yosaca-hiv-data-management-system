# Initial schema for YOSACA aggregate treatment reports.
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(
            name='UserProfile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('role', models.CharField(choices=[('ADMIN', 'YOSACA Admin'), ('LGA', 'LGA Coordinator')], max_length=10)),
                ('lga', models.CharField(blank=True, choices=[(x, x) for x in ['Bade','Bursari','Damaturu','Fika','Fune','Geidam','Gujba','Gulani','Jakusko','Karasuwa','Machina','Nangere','Nguru','Potiskum','Tarmuwa','Yunusari','Yusufari']], max_length=40)),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='yosaca_profile', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='TreatmentReport',
            fields=[
                ('id', models.UUIDField(editable=False, primary_key=True, serialize=False)),
                ('lga', models.CharField(choices=[(x, x) for x in ['Bade','Bursari','Damaturu','Fika','Fune','Geidam','Gujba','Gulani','Jakusko','Karasuwa','Machina','Nangere','Nguru','Potiskum','Tarmuwa','Yunusari','Yusufari']], db_index=True, max_length=40)),
                ('facility', models.CharField(max_length=180)),
                ('period', models.CharField(db_index=True, max_length=7)),
                ('reporter', models.CharField(max_length=120)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField()),
                ('tx_new', models.PositiveIntegerField(default=0)),
                ('tx_curr', models.PositiveIntegerField(default=0)),
                ('tx_pvls', models.PositiveIntegerField(default=0)),
                ('tx_rtt', models.PositiveIntegerField(default=0)),
                ('tx_ml', models.PositiveIntegerField(default=0)),
                ('vl_eligible', models.PositiveIntegerField(default=0)),
                ('vl_tested', models.PositiveIntegerField(default=0)),
                ('vl_suppressed', models.PositiveIntegerField(default=0)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('updated_by', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to=settings.AUTH_USER_MODEL)),
            ],
            options={'ordering': ['-period', 'lga', 'facility']},
        ),
        migrations.AddConstraint(
            model_name='treatmentreport',
            constraint=models.UniqueConstraint(fields=('lga', 'facility', 'period'), name='unique_facility_lga_month'),
        ),
    ]

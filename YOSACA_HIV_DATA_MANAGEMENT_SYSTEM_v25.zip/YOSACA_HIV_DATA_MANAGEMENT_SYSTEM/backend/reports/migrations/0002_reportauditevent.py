from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ('reports', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='ReportAuditEvent',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('action', models.CharField(choices=[('REPORT_CREATED', 'Report created')], max_length=40)),
                ('occurred_at', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('metadata', models.JSONField(blank=True, default=dict)),
                ('actor', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='yosaca_audit_events', to=settings.AUTH_USER_MODEL)),
                ('report', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='audit_events', to='reports.treatmentreport')),
            ],
            options={'ordering': ['-occurred_at']},
        ),
    ]

# YOSACA API starter (Django REST Framework)

This is a starter API for aggregate HIV Treatment reporting, not a deployed service. It provides JWT token endpoints and a role-filtered reports endpoint. Accounts must have a `UserProfile` with role `ADMIN` or `LGA`; an LGA profile must have its assigned LGA set. Accounts without a profile are denied access to report data.

## Local setup
1. Create a PostgreSQL database and user, then set environment variables from `.env.example` (never commit real secrets).
2. Create a virtual environment and install `requirements.txt`.
3. Run `python manage.py makemigrations reports` and `python manage.py migrate`.
4. Run `python manage.py createsuperuser`, start the server, sign in to `/admin/`, and create a `UserProfile` for each approved account.
5. Start locally with `python manage.py runserver`. Endpoints: `POST /api/token/`, `POST /api/token/refresh/`, `GET /api/me/` (server-assigned account role/LGA), `GET/POST /api/reports/`, and `GET /api/summary/` (role-scoped aggregate totals). Call `/api/me/` after obtaining a JWT; the mobile app must use the role and LGA returned by the server, never a role selected locally.

## Before deployment
- Deploy only behind HTTPS; use a managed secret store and a production WSGI server.
- Configure backups, monitoring, audit trails, retention, least-privilege accounts, password/MFA policy, incident response and access reviews.
- Have the state data owner approve indicators, aggregation rules, duplicate/update policy, privacy notice and hosting location.
- Test permissions with separate admin and coordinator accounts and test migration, restore, rate limits, concurrency and offline conflict behavior.
- This starter does not yet implement an account provisioning workflow or fully validated sync conflict resolution. The API records a minimal append-only audit event when a report is created; production deployments still need centralized log collection, retention controls, and independent review. Do not use identifiable patient-level data.

## Permission regression tests
After configuring a test database, run `python manage.py test reports`. The tests cover LGA filtering, cross-LGA submission rejection, admin visibility, fail-closed behavior for accounts without a YOSACA profile, the server-assigned profile endpoint, and viral-load count consistency. They use synthetic demonstration records only.

## Container deployment starter

A Dockerfile and `compose.yaml` are included as a deployment starting point. Copy `.env.example` to `.env`, set a unique long `DJANGO_SECRET_KEY`, a strong `POSTGRES_PASSWORD`, and the approved `DJANGO_ALLOWED_HOSTS`, then review the configuration with your infrastructure/security team before starting containers. Run from this directory with `docker compose up --build -d`; apply migrations with `docker compose exec api python manage.py migrate`. The API binds to `127.0.0.1:8000` and should sit behind an approved HTTPS reverse proxy; it is not exposed directly to the public internet by this compose file. `/health/` checks database readiness.

For local automated tests without PostgreSQL, set `DJANGO_TEST_SQLITE=1` and run `python manage.py test reports`. This SQLite option is for development/CI only, not production. CI runs Django checks, verifies migrations are in sync, and executes the permission regression tests.

The included container files do not make this service production-approved by themselves. No real data should be entered until hosting, HTTPS, secrets, backup/restore, audit logging, account provisioning, authorization, and data-owner approvals are completed.


### Safer retries and secret configuration

- Mobile report creation is idempotent for the same report UUID and identical payload. If the server accepted a report but the response was lost, retrying returns the existing report. Reusing an ID with different values, or submitting another report for an already-used LGA/facility/month, returns HTTP 409.
- With `DJANGO_DEBUG=0`, the server refuses to start if `DJANGO_SECRET_KEY` is missing or still set to the example placeholder. Generate a long, random secret and keep it out of source control. `backend/.env.example` is a template, not a deployable secret file.
- For local tests, set `DJANGO_TEST_SQLITE=1` and a non-production `DJANGO_SECRET_KEY`, then run `python manage.py test reports`.


### Report immutability safeguard

The mobile reports API currently supports listing and creating reports only. PUT, PATCH, and DELETE are intentionally disabled until the data owner approves an audited correction workflow. If a report needs correction, use the organization's approved administrator process rather than editing/deleting it directly through this starter API. Regression tests cover disabled mutation methods and invalid reporting months.


### Minimal report audit trail (v11)

Successful API report creation writes a `ReportAuditEvent` in the same database transaction as the report. The event records the actor, report reference, action, timestamp, and minimal source metadata only; it intentionally does not duplicate indicator values or notes. The Django admin displays audit events as read-only and disables adding, changing, and deleting them through the admin UI. This is a useful baseline, not a tamper-proof audit system: production should restrict database access, forward logs to controlled storage, and approve retention and review procedures.


### Aggregate summary endpoint (v12)

`GET /api/summary/` returns aggregate indicator totals and counts grouped by reporting month. YOSACA Admin accounts see all LGAs; LGA Coordinator accounts are filtered to their server-assigned LGA. An optional `?period=YYYY-MM` filter narrows the summary to one reporting month. The response deliberately excludes facility names, reporter names, and notes. This endpoint requires JWT authentication and an explicitly configured YOSACA profile. Regression tests cover LGA scoping, admin totals, invalid month filters, and unprofiled accounts.

### Dashboard period selector (v15)
The Flutter dashboard can filter server aggregate totals by reporting month with `GET /api/summary/?period=YYYY-MM`. The `by_period` list remains scoped to the user's authorization but includes all available months, so the mobile month selector can switch periods without needing a separate discovery request. Totals remain filtered to the selected month.


### Production startup checks (v20)

When `DJANGO_DEBUG=0` and the app is not running in the explicit CI/test SQLite mode, startup now fails if `DJANGO_ALLOWED_HOSTS` is unset or left at the localhost-only defaults, or if `POSTGRES_PASSWORD` is empty or still an example/default value. Set exact approved hostnames and a unique database password in the deployment secret store. These checks reduce common configuration mistakes; they do not replace HTTPS, a security review, backup/restore testing, or data-owner approval.

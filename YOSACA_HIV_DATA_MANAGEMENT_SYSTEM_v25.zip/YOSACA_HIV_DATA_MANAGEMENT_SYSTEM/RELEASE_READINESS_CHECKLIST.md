# YOSACA release-readiness checklist

Use this checklist before any field deployment. A successful source preflight is not a release approval.

## 1. Source and automated checks

- [ ] Run `python scripts/preflight_release.py` and retain its output.
- [ ] In backend CI, install `backend/requirements.txt`, then run `python manage.py check`, `python manage.py makemigrations --check --dry-run`, and `python manage.py test reports`.
- [ ] In an installed Flutter stable environment, run `./scripts/prepare_android_build.sh`, `flutter pub get`, `flutter analyze`, and `flutter test`.
- [ ] Build the controlled-testing package with `flutter build apk --debug --dart-define=YOSACA_API_URL=https://<approved-host>`.
- [ ] Install the APK on supported Android versions and test offline entry, app restart, PDF export, login, sync retry, duplicate submission, and role/LGA scoping.
- [ ] Review dependency updates and the generated CI logs; fix all failures rather than suppressing them.

## 2. API and infrastructure

- [ ] Use an approved HTTPS hostname and verify certificate handling from the target devices.
- [ ] Set a unique high-entropy `DJANGO_SECRET_KEY` and strong unique database credentials via secret management, not source control.
- [ ] Set exact `DJANGO_ALLOWED_HOSTS`; configure HTTPS redirects and secure cookies/proxy settings to match the actual deployment topology.
- [ ] Use PostgreSQL for production; run migrations from a controlled release step.
- [ ] Configure encrypted backups and prove restoration; define retention, monitoring, incident response, and audit-log review.
- [ ] Confirm authentication, rate limits, account offboarding, role/LGA assignment, and access review procedures.

## 3. Data governance and field acceptance

- [ ] Obtain written approval from the responsible YOSACA/state data owner and complete privacy/security review.
- [ ] Confirm the app stores only approved aggregate indicators and no patient identifiers or free-text patient details.
- [ ] Test with synthetic data only until approval is documented.
- [ ] Validate aggregate totals and report definitions with programme owners before operational use.
- [ ] Approve the signed production build and protect the organization signing key in managed secret storage.

## Release gate

Do not call the system production-ready or distribute it for real reporting until all applicable items above are checked and the responsible owner accepts the release. The current repository workflow builds a **debug APK for controlled testing**, not a production-signed release.

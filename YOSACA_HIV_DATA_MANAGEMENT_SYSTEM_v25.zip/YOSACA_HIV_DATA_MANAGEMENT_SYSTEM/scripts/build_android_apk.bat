@echo off
setlocal
cd /d "%~dp0\.."
where flutter >nul 2>nul || (echo ERROR: Install Flutter stable and add flutter to PATH.& exit /b 2)
where python >nul 2>nul || (echo ERROR: Install Python 3 and add python to PATH.& exit /b 2)
if "%YOSACA_API_URL%"=="" set "YOSACA_API_URL=https://your-approved-api-host"
echo [1/6] Source preflight
python scripts\preflight_release.py || exit /b 1
echo [2/6] Prepare Android Gradle wrapper
bash scripts/prepare_android_build.sh || exit /b 1
echo [3/6] Resolve Flutter dependencies
flutter pub get || exit /b 1
echo [4/6] Analyze Dart code
flutter analyze || exit /b 1
echo [5/6] Run Flutter tests
flutter test || exit /b 1
echo [6/6] Build debug APK
flutter build apk --debug --dart-define=YOSACA_API_URL=%YOSACA_API_URL% || exit /b 1
if not exist build\app\outputs\flutter-apk\app-debug.apk (echo ERROR: APK file was not created.& exit /b 1)
echo SUCCESS: build\app\outputs\flutter-apk\app-debug.apk
echo This is a debug/testing APK, not a production-signed release.
endlocal

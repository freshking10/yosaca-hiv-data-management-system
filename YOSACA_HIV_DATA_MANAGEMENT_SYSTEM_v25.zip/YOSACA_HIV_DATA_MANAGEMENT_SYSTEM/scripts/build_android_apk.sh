#!/usr/bin/env bash
# One-command controlled-testing Android build. Requires Flutter stable + Android SDK.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

for tool in flutter python; do
  command -v "$tool" >/dev/null 2>&1 || {
    echo "ERROR: '$tool' is required. Install Flutter stable and Python 3 first." >&2
    exit 2
  }
done

API_URL="${YOSACA_API_URL:-https://your-approved-api-host}"
case "$API_URL" in
  https://*) ;;
  *) echo "ERROR: YOSACA_API_URL must use HTTPS. Use the placeholder only for controlled/offline build testing." >&2; exit 2 ;;
esac

echo "[1/6] Source preflight"
python scripts/preflight_release.py

echo "[2/6] Prepare Android Gradle wrapper"
./scripts/prepare_android_build.sh

echo "[3/6] Resolve Flutter dependencies"
flutter pub get

echo "[4/6] Analyze Dart code"
flutter analyze

echo "[5/6] Run Flutter tests"
flutter test

echo "[6/6] Build debug APK (controlled testing only)"
flutter build apk --debug --dart-define="YOSACA_API_URL=$API_URL"
APK="$ROOT/build/app/outputs/flutter-apk/app-debug.apk"
if [[ ! -s "$APK" ]]; then
  echo "ERROR: Flutter build returned without a non-empty APK at $APK" >&2
  exit 1
fi
printf '\nSUCCESS: APK created: %s\n' "$APK"
printf 'This is a debug/testing APK, not a production-signed release.\n'

#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v flutter >/dev/null 2>&1 || { echo "Flutter SDK is required. Install Flutter first: https://docs.flutter.dev/get-started/install" >&2; exit 1; }

# The source package intentionally does not vendor Gradle wrapper binaries.
# Generate a clean Android scaffold, then copy only missing wrapper files so
# existing YOSACA Gradle configuration is not overwritten.
if [[ ! -f "$ROOT/android/gradlew" || ! -f "$ROOT/android/gradle/wrapper/gradle-wrapper.jar" ]]; then
  TMP="$(mktemp -d)"
  trap 'rm -rf "$TMP"' EXIT
  flutter create --platforms=android --org org.yosaca --project-name yosaca_hiv_data_management_system "$TMP/scaffold" >/dev/null
  mkdir -p "$ROOT/android/gradle/wrapper"
  cp "$TMP/scaffold/android/gradlew" "$ROOT/android/gradlew"
  cp "$TMP/scaffold/android/gradlew.bat" "$ROOT/android/gradlew.bat"
  cp "$TMP/scaffold/android/gradle/wrapper/gradle-wrapper.jar" "$ROOT/android/gradle/wrapper/gradle-wrapper.jar"
  cp "$TMP/scaffold/android/gradle/wrapper/gradle-wrapper.properties" "$ROOT/android/gradle/wrapper/gradle-wrapper.properties"
  chmod +x "$ROOT/android/gradlew"
fi

if [[ ! -f "$ROOT/android/local.properties" ]]; then
  FLUTTER_BIN="$(command -v flutter)"
  FLUTTER_ROOT="$(cd "$(dirname "$FLUTTER_BIN")/.." && pwd)"
  printf 'flutter.sdk=%s\n' "$FLUTTER_ROOT" > "$ROOT/android/local.properties"
fi

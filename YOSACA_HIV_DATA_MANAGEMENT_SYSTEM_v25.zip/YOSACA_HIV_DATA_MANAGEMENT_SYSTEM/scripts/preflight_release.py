#!/usr/bin/env python3
"""Dependency-light source preflight for YOSACA release handoff.

This does not replace Django/Flutter tests, security review, or a real APK build.
Run from any directory: python scripts/preflight_release.py
"""
from __future__ import annotations

import ast
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = (
    "pubspec.yaml",
    "lib/main.dart",
    "test/treatment_record_test.dart",
    "android/app/build.gradle.kts",
    "android/app/src/main/AndroidManifest.xml",
    "backend/manage.py",
    "backend/config/settings.py",
    "backend/reports/models.py",
    "backend/reports/views.py",
    "backend/reports/tests.py",
    ".github/workflows/flutter-android.yml",
    ".github/workflows/backend-tests.yml",
    "ANDROID_BUILD_GUIDE.md",
    "ASSEMBLE_APP_HAUSA.md",
    "scripts/build_android_apk.sh",
)


def main() -> int:
    errors: list[str] = []
    notes: list[str] = []

    for relative in REQUIRED:
        if not (ROOT / relative).is_file():
            errors.append(f"Missing required file: {relative}")

    if (ROOT / "pubspec.yaml").exists():
        try:
            import yaml  # type: ignore
            with (ROOT / "pubspec.yaml").open(encoding="utf-8") as stream:
                pubspec = yaml.safe_load(stream) or {}
            if pubspec.get("name") != "yosaca_hiv_data_management_system":
                errors.append("Unexpected Flutter package name in pubspec.yaml")
            if not pubspec.get("version"):
                errors.append("Flutter version is missing from pubspec.yaml")
            print("PASS: pubspec.yaml parsed")
        except ImportError:
            notes.append("PyYAML unavailable; skipped YAML semantic parsing")
        except Exception as exc:
            errors.append(f"pubspec.yaml could not be parsed: {exc}")

    try:
        ET.parse(ROOT / "android/app/src/main/AndroidManifest.xml")
        print("PASS: AndroidManifest.xml parsed")
    except Exception as exc:
        errors.append(f"Android manifest invalid: {exc}")

    backend = ROOT / "backend"
    py_files = list(backend.rglob("*.py"))
    for path in py_files:
        if "__pycache__" in path.parts:
            continue
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except (SyntaxError, UnicodeDecodeError) as exc:
            errors.append(f"Python syntax error in {path.relative_to(ROOT)}: {exc}")
    if not errors:
        print(f"PASS: Python syntax parsed ({len(py_files)} backend Python files found)")

    # Flag common accidental local endpoint configuration in the Android build workflow.
    workflow = ROOT / ".github/workflows/flutter-android.yml"
    if workflow.exists():
        text = workflow.read_text(encoding="utf-8")
        if "flutter build apk --debug" not in text:
            errors.append("Android workflow does not contain a debug APK build step")
        if "upload-artifact@v4" not in text:
            errors.append("Android workflow does not upload the APK artifact")
        if "workflow_dispatch" not in text:
            notes.append("Android workflow cannot be manually started from GitHub UI")
        if "replace-with-approved-yosaca-api.example" in text:
            notes.append("Android CI uses a placeholder API host; APK is for controlled offline/testing use only")

    # Keep generated caches and build products out of the source handoff.
    generated = [p for p in ROOT.rglob("*") if p.is_file() and ("__pycache__" in p.parts or p.suffix == ".pyc")]
    if generated:
        notes.append(f"Found {len(generated)} generated Python cache file(s); remove before packaging")

    if errors:
        print("\nPREFLIGHT FAILED")
        for item in errors:
            print(f"ERROR: {item}")
        for item in notes:
            print(f"NOTE: {item}")
        return 1

    print("\nPREFLIGHT PASSED: source structure and dependency-light checks only.")
    for item in notes:
        print(f"NOTE: {item}")
    print("NOT RUN: Django tests, Flutter analyze/tests, Android compilation, API integration, or security review.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
